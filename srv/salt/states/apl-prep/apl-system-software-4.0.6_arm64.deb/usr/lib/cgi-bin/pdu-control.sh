#!/bin/bash
echo "Content-type: text/html"
echo ""

cur_apl_sn=`cat /usr/local/cms/config/apl_serial`
apl_sn=`echo "$QUERY_STRING" | grep -oE "(^|[?&])apl_sn=[^&]+" | sed "s/%20/ /g" | awk -F "?" '{print $1}' | awk -F "=" '{print $2}'`
pdu_sn=`echo "$QUERY_STRING" | grep -oE "(^|[?&])apl_sn=[^&]+" | sed "s/%20/ /g" | awk -F "?" '{print $2}' | awk -F "=" '{print $2}'`
out_no=`echo "$QUERY_STRING" | grep -oE "(^|[?&])apl_sn=[^&]+" | sed "s/%20/ /g" | awk -F "?" '{print $3}' | awk -F "=" '{print $2}'`
action=`echo "$QUERY_STRING" | grep -oE "(^|[?&])apl_sn=[^&]+" | sed "s/%20/ /g" | awk -F "?" '{print $4}' | awk -F "=" '{print $2}'`
pwr_delay=`echo "$QUERY_STRING" | grep -oE "(^|[?&])apl_sn=[^&]+" | sed "s/%20/ /g" | awk -F "?" '{print $5}' | awk -F "=" '{print $2}'`
#cur_pdu_sn=`sudo /usr/local/cms/bin/pducontrol pdu_sn $pdu_sn get serial`
cur_pdu_sn=`cat /usr/local/cms/config/pdu_serial`

if [ "$cur_apl_sn" == "$apl_sn" ] && [ "$cur_pdu_sn" == "$pdu_sn" ]
 then
    echo "Request accepted"
	if [ "$action" == "reset" ]
	  then
            #sudo /usr/local/cms/bin/pducontrol pdu_sn $pdu_sn set out $out_no off
            snmpset -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.5800.3.1.3.$out_no integer 0
	    sleep $pwr_delay
            #sudo /usr/local/cms/bin/pducontrol pdu_sn $pdu_sn set out $out_no on
	    snmpset -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.5800.3.1.3.$out_no integer 1
	  else
   	    if [ "$action" == "on" ]
               then
		 snmpset -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.5800.3.1.3.$out_no integer 1
	       else 
		 snmpset -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.5800.3.1.3.$out_no integer 0
	    fi
		#sudo /usr/local/cms/bin/ledcontrol set led vpn flash
	        #sudo /usr/local/cms/bin/pducontrol pdu_sn $pdu_sn set out $out_no $action
	fi
 else
    echo "Request refused"
fi

echo ""
echo ""

sudo /usr/local/cms/scripts/publish.sysinfo.sh
