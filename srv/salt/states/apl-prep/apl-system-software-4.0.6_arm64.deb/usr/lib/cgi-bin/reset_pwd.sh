#!/bin/bash
echo "Content-type: text/html"
echo ""

cur_apl_sn=`cat /usr/local/cms/config/apl_serial`
apl_sn=`echo "$QUERY_STRING" | grep -oE "(^|[?&])apl_sn=[^&]+" | sed "s/%20/ /g" | awk -F "?" '{print $1}' | awk -F "=" '{print $2}'`

if [ "$cur_apl_sn" == "$apl_sn" ]
 then
    echo "Request accepted"
# TODO Тут тоже ledcontrol лишний
    sudo /usr/local/cms/bin/ledcontrol set led vpn flash
    sudo /usr/local/cms/scripts/reset_pwd.sh
 else
    echo "Request refused"
fi

echo ""
echo ""
