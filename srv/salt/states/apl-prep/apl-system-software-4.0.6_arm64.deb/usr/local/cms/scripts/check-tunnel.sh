#!/bin/bash

DELAY_AFTER_REBOOT=300
CHECK_FILE=/tmp/check-tunnel.$1
#LOG_FILE=/tmp/check-tunnel.log
LOG_FILE=/var/log//check-tunnel.log

tty -s && exec &>> >(tee -a ${LOG_FILE}) || exec &>> ${LOG_FILE}

[ -z "$1" ] && echo Device name is required! && exit 1
[ -z "$2" ] && echo Interval in seconds required! && exit 2
[ $(echo "$2" | grep -E '^[0-9]+$') ] || exit 3

echo
date
echo Checking interface $1, lifetime $2 seconds ...

[ $(($(date +'%s') - $(date -d "$(who -b|sed -r 's/^[^0-9]+//')" +'%s'))) -le ${DELAY_AFTER_REBOOT} ] && echo Recently rebooted ... && exit 0

[ ! -f ${CHECK_FILE} ] && touch ${CHECK_FILE}

ip link | grep -q $1 && touch ${CHECK_FILE} && echo Found interface $1 ... && exit 0

echo Missed interface $1 ...

[ $(($(date +'%s') - $(stat -c '%Y' ${CHECK_FILE}))) -gt $2 ] && echo Time to reboot ... && reboot && exit 0

exit 0
