#! /bin/bash
#
# netfailover
#
# include var: hosts, packets, ints, interval from netfailover.conf
# log file /var/log/netfailover.log through crontab
# * * * * * root  /usr/local/cms/scripts/netfailover.sh >> /var/log/netfailover.log
source /usr/local/cms/config/netfailover.conf
source /usr/local/cms/scripts/netfailover_init.sh
source /usr/local/cms/scripts/netfailover_sw.sh
