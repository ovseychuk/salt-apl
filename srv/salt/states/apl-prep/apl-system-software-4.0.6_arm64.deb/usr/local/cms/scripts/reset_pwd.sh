#! /bin/bash

cat /usr/local/cms/config/template.shadow > /etc/shadow
