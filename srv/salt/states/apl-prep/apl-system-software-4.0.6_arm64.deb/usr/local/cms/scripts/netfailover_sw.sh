# netfailover_sw

for int in $ints;do
  if ! /sbin/ip link show $int &>/dev/null; then continue; fi
  for host in $hosts ;do
    host_reply=`ping -w 3 -c 3 -i 1 -I $int $host | awk '/received/ {print $4}'`
    [ x"$host_reply" != "x" ] && [ "$host_reply" != "0" ] && break
   done
  [ x"$host_reply" != "x" ] && [ "$host_reply" != "0" ] && break
done

dfgwcur=`route -n | awk '/UG    5      0/ {print $2}'`
dfgwnew=`route -n | grep "$int" | awk '/ UG / {print \$2}'`
dfintcur=`route -n | awk '/UG    5      0/ {print $8}'`
dfintnew=$int

if [[ "$dfintcur" != "$dfintnew" && "$host_reply" != "0" ]] ;then
  date;route -n | grep " UG    5      0 "
#   | grep $dfintcur
  ip route del metric 5
  route add default gw $dfgwnew metric 5
  systemctl restart openvpn@client
  /usr/local/cms/scripts/netmon.sh > /var/log/netmon.log
  date;route -n | grep " UG    5      0 "
#   | grep $dfintnew
fi
