#!/bin/sh

#************************************************
#*                                              *
#*          Business Ecosystems (C)             *
#*     Config from apl-system-software package  *
#*         Do not touch unnecessarily           *
#*                                              *
#************************************************

PATH=$PATH:/usr/local/cms/bin:/usr/local/cms/scripts
export PATH


