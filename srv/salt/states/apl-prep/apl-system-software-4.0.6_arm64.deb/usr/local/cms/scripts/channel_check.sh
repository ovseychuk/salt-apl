#!/bin/bash

while true
do

app_active_if=`route -n | grep 0.0.0.0 | grep UG | head -n1 | awk -F " " '{print $8}'`

case $app_active_if in
	eth0)
	#sudo /usr/local/cms/bin/ledcontrol set led gsm off
	#sudo /usr/local/cms/bin/ledcontrol set led wifi off
	#sudo /usr/local/cms/bin/ledcontrol set led ether on
	;;
	wlan0)
	#sudo /usr/local/cms/bin/ledcontrol set led gsm off
	#sudo /usr/local/cms/bin/ledcontrol set led ether off	
	#sudo /usr/local/cms/bin/ledcontrol set led wifi on
	;;
	ppp0)
		#sudo /usr/local/cms/bin/ledcontrol set led wifi off
		#sudo /usr/local/cms/bin/ledcontrol set led ether off
		#sudo /usr/local/cms/bin/ledcontrol set led gsm on
	;;
esac

sleep 10
done
