#! /bin/bash
#
# netmon
#
#include var: hosts,packets,ints,interval from netfailover.conf
# log file /var/log/netmon.log through crontab
# */10 * * * * root  /usr/local/cms/scripts/netmon.sh > /var/log/netmon.log
source /usr/local/cms/config/netfailover.conf
source /usr/local/cms/scripts/netmon_test.sh
