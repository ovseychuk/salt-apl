# netmon_test
#Progrev
for int in $ints;do
 if ! /sbin/ip link show $int &>/dev/null; then continue; fi
 for host in $netmon_hosts ;do
   ping -w 1 -c 1 -I $int $host >/dev/null
 done
done
date
for int in $ints;do
 if ! /sbin/ip link show $int &>/dev/null; then continue; fi
 for host in $netmon_hosts ;do
#  echo "======================================================================"
#  echo "ping -w 6 -c 3 -i 1 -I $int $host"
  host_reply=`ping -w 6 -c 3 -i 1 -I $int $host | egrep "received|rtt"`
#  echo $host_reply
  host_reply=`echo $host_reply | awk '{print $4" "$6" "$14}'`
#  echo $host_reply
  status=`echo $host_reply | awk '{print $1}'`
  loss=`echo $host_reply | awk '{print $2}'`
  avg=`echo $host_reply | awk -F "/" '{print $2}'`
#  echo $int $host $status $loss $avg
  [ "$status" != "0" ] && break
 done
 echo $int $host $status $loss $avg
 #[ "$host_reply" != "0" ] && break
done
#echo "-----------------------"
#if [[ "$dfintcur" != "$dfintnew" && "$host_reply" != "0" ]] ;then
#date;route -n | grep " UG    5      0 "
## | grep $dfintcur
#route add default gw $dfgwnew metric 5
#date;route -n | grep " UG    5      0 "
## | grep $dfintnew
#fi
