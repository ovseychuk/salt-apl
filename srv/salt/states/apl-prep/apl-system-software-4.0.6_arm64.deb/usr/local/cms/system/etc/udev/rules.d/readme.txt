#Current APL Port Configuration (20-apl.rules)

#####################
#-----# COM1 | COM3 #
# ETH #-------------#
#-----# COM2 | COM4 #
#####################