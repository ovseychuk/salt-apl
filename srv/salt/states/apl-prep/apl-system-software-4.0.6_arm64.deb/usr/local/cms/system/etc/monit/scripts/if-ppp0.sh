#!/bin/bash

/sbin/ip link show ppp0 2>&1
exit $?
