#!/bin/bash

f=/proc/meminfo

MEM_TOTAL=(`cat $f | grep "MemTotal:" | awk '{print $2}'`)
MEM_FREE=(`cat $f | grep "MemFree:" | awk '{print $2}'`)
#echo "$MEM_TOTAL $MEM_FREE"


let "MEM_PERCENT=(1000*($MEM_TOTAL-$MEM_FREE))/$MEM_TOTAL/10"

echo $MEM_PERCENT
