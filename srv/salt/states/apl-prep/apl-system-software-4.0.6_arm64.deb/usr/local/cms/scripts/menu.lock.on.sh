#!/bin/bash

# capture CTRL+C, CTRL+Z and quit singles using the trap
trap '' SIGINT
trap '' SIGQUIT
trap '' SIGTSTP

# Create infinite while loop
while true
do
	clear
	# display menu
		echo "----------------------------------------------------"
		echo "                                                    "
		echo "                BUSINESS ECOSYSTEMS                 "
		echo "           CMS APPLIANCE VERIFICATION WIZARD        "
		echo "                                                    "
		echo "                   LOCKDOWN MODE                    "
		echo "----------------------------------------------------"
		echo "[1] Run ping utility                                "
		echo "[2] Run traceroute utility                          "
		echo "[3] Check configuration and connection status       "
		echo "[4] Exit                                            "
		echo "----------------------------------------------------"

	# get input from the user
		read -p "Enter your choice [0-4]:" choice

	# make decision using case..in..esac
		case $choice in
			1)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[1] Run ping utility                                "
		echo "----------------------------------------------------"
		echo -n "Enter target IP address or domain name: "
		read mnu_ping
			ping $mnu_ping -w 10 -c 5 -i 1
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
			2)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[2] Run traceroute utility                          "
		echo "----------------------------------------------------"
		echo -n "Enter target IP address or domain name: "
		read mnu_traceroute
			traceroute $mnu_traceroute -n
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
			3)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[3] Check configuration and connection status       "
		echo "----------------------------------------------------"
		echo "----------------Current configuration---------------"

######################Eth0 Settings##################################################################################

			curr_eth_dhcp=`cat /etc/network/interfaces | grep iface | grep eth0 | awk -F " " '{print $4}'`
			#curr_eth_address=`ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
			#curr_eth_subnet=`ifconfig eth0 | grep 'inet addr:' | cut -d: -f4 | awk '{ print $1}'`
			curr_eth_address=`ifconfig eth0 | grep 'inet' | cut -d: -f2 | awk '{ print $2}'`
			curr_eth_subnet=`ifconfig eth0 | grep 'inet' | cut -d: -f4 | awk '{ print $4}'`
			curr_eth_gateway=`route -n | grep eth0 | grep 0.0.0.0 | grep UG | head -n1 | awk '{print $2}'`

######################Wlan0 Settings#################################################################################

			curr_wifi_enable=`cat /etc/network/interfaces 2>/dev/null | grep wpa | wc -l | sed 's/2/Enabled/g' | sed 's/0/Disabled/g'`
			curr_wifi_ssid=`cat /etc/network/interfaces 2>/dev/null | grep ssid | awk -F " " '{print $2}' | sed 's/"//g'`
			curr_wifi_key=`cat /etc/network/interfaces 2>/dev/null | grep psk | awk -F " " '{print $2}' | sed 's/"//g'`
			#curr_wifi_address=`ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
			#curr_wifi_subnet=`ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f4 | awk '{ print $1}'`
			curr_wifi_address=`ifconfig wlan0 | grep 'inet' | cut -d: -f2 | awk '{ print $2}'`
			curr_wifi_subnet=`ifconfig wlan0 | grep 'inet' | cut -d: -f4 | awk '{ print $4}'`
			curr_wifi_gateway=`route -n | grep wlan0 | grep 0.0.0.0 | grep UG | head -n1 | awk '{print $2}'`

######################BE CMS Manager Settings#######################################################################

			#curr_mgr_address=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote" | awk -F " " '{print $2}'`
			#curr_vpn_port=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote" | awk -F " " '{print $3}'`
			curr_mgr_address=`cat /etc/openvpn/client.conf 2>/dev/null | awk -F " " '/remote / {print $2}'`
			curr_vpn_port=`cat /etc/openvpn/client.conf 2>/dev/null | awk -F " " '/remote / {print $3}'`
			curr_mgr_tunnel_ip=`cat /usr/local/cms/config/soap 2>/dev/null | grep "soap_host" | awk -F "=" '{print $2}'`
			curr_control_url=`cat /usr/local/cms/config/apl_manager.conf | grep url | awk -F " " '{print $3}'`
			curr_context=`cat /usr/local/cms/config/apl_manager.conf | grep context | awk -F " " '{print $3}'`
			curr_vpn_status=`ifconfig | grep "tun0" | awk -F " " '{print $1}' | sed 's/tun0/'Connected'/g'`
			curr_app_active_if=`route -n | grep 0.0.0.0 | grep UG | head -n1 | awk -F " " '{print $8}' | sed 's/eth0/Ethernet/g' | sed 's/wlan0/Wi-Fi/g' | sed 's/ppp0/Modem/g'`

######################DNS Settings##################################################################################

			#curr_dns1=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $2}'`
			#curr_dns2=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $4}'`
			#curr_dns3=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $6}'`
			curr_dns1=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $1}'`
			curr_dns2=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $2}'`
			curr_dns3=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $3}'`

######################NTP Settings##################################################################################

			#curr_ntp1=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $2}'`
			#curr_ntp2=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $5}'`
			#curr_ntp3=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $8}'`
			#curr_ntp4=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $11}'`
			curr_ntp1=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $1}'`
			curr_ntp2=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $2}'`
			curr_ntp3=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $3}'`
			curr_ntp4=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $4}'`

######################APL Settings###################################################################################

			curr_os_ver=`apt-cache show apl-system-software | grep Version | awk -F ": " '{print $2}'`
			curr_apl_sn_led=`cat /usr/local/cms/config/apl_serial`
			curr_apl_sn="F$curr_apl_sn_led"
			curr_apl_model=`cat /usr/local/cms/config/apl_model`

######################Additional Devices Settings####################################################################

			#curr_gsm_status=`lsusb | grep GSM | awk -F " " '{print $11}' | sed 's/E398/'Installed'/g'`
			curr_gsm_status=`lsusb | grep Modem | awk -F " " '{print $11}' | sed 's/Networkcard/'Installed'/g'`
			# TODO Need to plug in web-cam and weather board and test them properly
			curr_weatherboard_status=`ls /dev/ | grep "i2c-1" | sed 's/i2c-1/'Installed'/g'`
			curr_cam_status=`ls /dev/ | grep "video0" | sed 's/video0/'Installed'/g'`

######################Netmon Settings################################################################################

			curr_netmon_hosts=`cat /usr/local/cms/config/netfailover.conf | grep netmon_hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`
			curr_netmon_timeout=`cat /usr/local/cms/config/netfailover.conf | grep netmon_timeout | awk -F "=" '{ print $2}' | sed 's/"/''/g' | awk '{ print $1}'`
			curr_netmon_packets=`cat /usr/local/cms/config/netfailover.conf | grep netmon_packets | awk -F "=" '{ print $2}'`
			curr_netmon_interval=`cat /usr/local/cms/config/netfailover.conf | grep netmon_interval | awk -F "=" '{ print $2}'`
			#curr_netfw_interface_pri=`cat /usr/local/cms/config/netfailover.conf | grep ints | awk -F "=" '{ print $2}' | sed 's/"/''/g' | sed 's/eth0 ppp0 wlan0/Ethernet, GSM, Wi-Fi/g' | sed 's/eth0 wlan0 ppp0/Ethernet, Wi-Fi, GSM/g' | sed 's/ppp0 eth0 wlan0/GSM, Ethernet, Wi-Fi/g' | sed 's/ppp0 wlan0 eth0/GSM, Wi-Fi, Ethernet/g' | sed 's/wlan0 ppp0 eth0/Wi-Fi, GSM, Ethernet/g' | sed 's/wlan0 eth0 ppp0/Wi-Fi, GSM, Ethernet/g'`
			curr_netfw_interface_pri=`cat /usr/local/cms/config/netfailover.conf | grep ints | awk -F "=" '{ print $2}' | sed 's/"/''/g' | sed 's/eth0 ppp0 wlan0/Ethernet, Modem, Wi-Fi/g' | sed 's/eth0 wlan0 ppp0/Ethernet, Wi-Fi, Modem/g' | sed 's/ppp0 eth0 wlan0/Modem, Ethernet, Wi-Fi/g' | sed 's/ppp0 wlan0 eth0/Modem, Wi-Fi, Ethernet/g' | sed 's/wlan0 ppp0 eth0/Wi-Fi, Modem, Ethernet/g' | sed 's/wlan0 eth0 ppp0/Wi-Fi, Modem, Ethernet/g'`
			curr_netfw_hosts=`cat /usr/local/cms/config/netfailover.conf | grep ^hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`

######################Time & Date Settings###########################################################################

			#curr_timezone=`timedatectl | grep Timezone | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
			curr_timezone=`timedatectl | grep "Time zone" | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
			curr_local_time=`timedatectl | grep "Local time" | awk -F " " '{print $4 " " $5}'`

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Ethernet settings ***"
			if [ "$curr_eth_dhcp" = "dhcp" ]
				then
					echo "Ethernet DHCP client:           enabled"
				else
					echo "Ethernet DHCP client:           disabled"
			fi
		echo "Ethernet IP address:            $curr_eth_address"
		echo "Ethernet subnet mask:           $curr_eth_subnet"
		echo "Ethernet default gateway:       $curr_eth_gateway"

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Wi-Fi settings ******"
			if [ "$curr_wifi_enable" = "Enabled" ]
				then
					echo "Wi-Fi inteface:             enabled"
					echo "Wi-Fi IP address:           $curr_wifi_address"
					echo "Wi-Fi subnet mask:          $curr_wifi_subnet"
					echo "Wi-Fi default gateway:      $curr_wifi_gateway"
					echo "Wi-Fi SSID:                 $curr_wifi_ssid"
					echo "Wi-Fi KEY:                  $curr_wifi_key"
				else
					echo "Wi-Fi inteface:             disabled"
			fi

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Global Settings *****"
		echo "CMS Manager VPN address:        $curr_mgr_address"
		echo "CMS Manager Tunnel IP address:  $curr_mgr_tunnel_ip"
		echo "VPN port:                       $curr_vpn_port"
		echo "Control URL:                    $curr_control_url"
		echo "First DNS IP address:           $curr_dns1"
		echo "Second DNS IP address:          $curr_dns2"
		echo "Third DNS IP address:           $curr_dns3"
		echo "First NTP IP address:           $curr_ntp1"
		echo "Second NTP IP address:          $curr_ntp2"
		echo "Third NTP IP address:           $curr_ntp3"
		echo "Fourth NTP IP address:          $curr_ntp4"

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Failover Settings ***"
		echo "Netfailver interface priority:  $curr_netfw_interface_pri"
		echo "Netfailver hosts:               $curr_netfw_hosts"
		echo "Netmon hosts:                   $curr_netmon_hosts"
		echo "Netmon timeout:                 $curr_netmon_timeout"
		echo "Netmon packets:                 $curr_netmon_packets"
		echo "Netmon interval:                $curr_netmon_interval"

###################################################################################################################################################################################################

		echo "----------------- Connection status ----------------"
		echo "MGMT server status:             $curr_vpn_status"
		echo "App active interface:           $curr_app_active_if"
		echo "Timezone:                       $curr_timezone"
		echo "Local Time:                     $curr_local_time"

###################################################################################################################################################################################################

		echo "---------------- System information ----------------"
		echo "Appliance SN:                   BE-$curr_apl_sn"
		echo "Appliance Model:                $curr_apl_model"
		echo "Appliance OS version:           $curr_os_ver"
		echo "GSM Modem status:               $curr_gsm_status"
		echo "Weatherboard status:            $curr_weatherboard_status"
		echo "Camera status:                  $curr_cam_status"

###################################################################################################################################################################################################

		read -p "Press [Enter] key to continue..." readEnterKey
		;;
			4)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[4] Exit                                            "
		echo "----------------------------------------------------"
		echo -n "Do you want a exit? [Yes/No]: "
		read mnu_exit
			if [ "$mnu_exit" = "Yes" ] || [ "$mnu_exit" = "yes" ] || [ "$mnu_exit" = "Y" ] || [ "$mnu_exit" = "y" ] || [ "$mnu_exit" = "YES" ]
				then
					echo "Exit..."
				sleep 1
				exit 0
			fi
		;;
			*)
		echo "Error: Invalid option..."
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
		esac

done
###################################################################################################################################################################################################