#!/bin/bash

# capture CTRL+C, CTRL+Z and quit singles using the trap
trap '' SIGINT
trap '' SIGQUIT
trap '' SIGTSTP

# Create infinite while loop
while true
do
	clear
# display menu
		echo "----------------------------------------------------"
		echo "                                 					  "
		echo "                BUSINESS ECOSYSTEMS                 "
		echo "           CMS APPLIANCE CONFIGURATION WIZARD       "
		echo "                                                    "
		echo "----------------------------------------------------"
		echo "[1] Configure Ethernet interface                    "
		echo "[2] Configure Wi-Fi interface                       "
		echo "[3] Configure local credentials                     "
		echo "[4] Configure global settings                       "
		echo "[5] Run ping utility                                "
		echo "[6] Run traceroute utility                          "
		echo "[7] Check configuration and connection status       "
		echo "[8] Apply configuration and reboot                  "
		echo "[9] Discard changes and exit                        "
		echo "----------------------------------------------------"
# get input from the user
		read -p "Enter your choice [0-9]: " choice
# make decision using case..in..esac
		case $choice in
				1)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[1] Configure Ethernet interface                    "
		echo "----------------------------------------------------"
		echo -n "Enable DCHP client? [Yes/No]: "
		read mnu_eth_dhcp
			if [ "$mnu_eth_dhcp" = "Yes" ] || [ "$mnu_eth_dhcp" = "yes" ] || [ "$mnu_eth_dhcp" = "Y" ] || [ "$mnu_eth_dhcp" = "y" ] || [ "$mnu_eth_dhcp" = "YES" ]
				then
					mnu_eth_dhcp="Yes"
					mnu_eth_address=""
					mnu_eth_subnet=""
					mnu_eth_gateway=""
				else
					mnu_eth_dhcp="No"
					echo -n "Configure Static address? [Yes/No]: "
					read mnu_eth_static
						if [ "$mnu_eth_static" = "Yes" ] || [ "$mnu_eth_static" = "yes" ] || [ "$mnu_eth_static" = "Y" ] || [ "$mnu_eth_static" = "y" ] || [ "$mnu_eth_static" = "YES" ]
							then
								mnu_eth_static="Yes"
								incorrect=yes
							while [ "$incorrect" = "yes" ]
								do
									echo -n "Enter Ethernet IP Address: "
									read mnu_eth_address
										validate_ip=`echo $mnu_eth_address | grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"`
											if [ "$mnu_eth_address" = "$validate_ip" ]
												then
													incorrect=no
												else
													incorrect=yes
													echo "*** Incorrect value ***"
												fi
								done
									incorrect=yes
							while [ "$incorrect" = "yes" ]
								do
									echo -n "Enter Subnet Mask: "
									read mnu_eth_subnet
										validate_subnet=`echo $mnu_eth_subnet | grep -E -o "(128|192|224|240|248|252|254|255)\.(0|128|192|224|240|248|252|254|255)\.(0|128|192|224|240|248|252|254|255)\.(0|128|192|224|240|248|252|254|255)"`
											if [ "$mnu_eth_subnet" = "$validate_subnet" ]
												then
													incorrect=no
												else
													incorrect=yes
													echo "*** Incorrect value ***"
											fi
								done
									incorrect=yes
							while [ "$incorrect" = "yes" ]
								do
									echo -n "Enter Default Gateway: "
									read mnu_eth_gateway
										validate_gateway=`echo $mnu_eth_gateway | grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"`
											if [ "$mnu_eth_gateway" = "$validate_gateway" ]
												then
													incorrect=no
												else
													incorrect=yes
												echo "*** Incorrect value ***"
											fi
								done
				else
					mnu_eth_static="No"
					mnu_eth_dhcp="Yes"
						fi
			fi
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
				2)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[2] Configure Wi-Fi interface                       "
		echo "----------------------------------------------------"
		echo -n "Enable Wi-Fi interface? [Yes/No]: "
		read mnu_wifi_enable
			if [ "$mnu_wifi_enable" = "Yes" ] || [ "$mnu_wifi_enable" = "yes" ] || [ "$mnu_wifi_enable" = "Y" ] || [ "$mnu_wifi_enable" = "y" ] || [ "$mnu_wifi_enable" = "YES" ]
				then
					mnu_wifi_enable="Yes"
					echo -n "Enter SSID: "
					read mnu_wifi_ssid
					echo -n "Enter Key: "
					read mnu_wifi_key
				else
					mnu_wifi_enable="No"
			fi
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
				3)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[3] Configure local credentials                     "
		echo "----------------------------------------------------"
		echo -n
			passwd cms
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
				4)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[4] Configure global settings                       "
		echo "----------------------------------------------------"
		echo -n "Enter CMS Manager VPN address or domain name: "
		read mnu_mgr_address
		echo -n "Enter VPN port: "
		read mnu_vpn_port
		echo -n "Enter CMS Manager Tunnel IP address: "
		read mnu_mgr_tunnel_ip
		echo -n "Enter Control URL host (example, http://): "
		read mnu_control_url
		echo -n "Enter Context: "
		read mnu_context
		incorrect=yes
			while [ "$incorrect" = "yes" ]
				do
					echo -n "Enter First DNS server IP address: "
					read mnu_dns1
						validate_dns1=`echo $mnu_dns1 | grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"`
							if [ "$mnu_dns1" = "$validate_dns1" ]
								then
									incorrect=no
								else
									incorrect=yes
									echo "*** Incorrect value ***"
							fi
				done
				incorrect=yes
				while [ "$incorrect" = "yes" ]
					do
						echo -n "Enter Second DNS server IP address: "
						read mnu_dns2
							validate_dns2=`echo $mnu_dns2 | grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"`
								if [ "$mnu_dns2" = "$validate_dns2" ]
									then
										incorrect=no
									else
										incorrect=yes
										echo "*** Incorrect value ***"
								fi
					done
					incorrect=yes
				while [ "$incorrect" = "yes" ]
					do
						echo -n "Enter Third DNS server IP address: "
						read mnu_dns3
							validate_dns3=`echo $mnu_dns3 | grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"`
								if [ "$mnu_dns3" = "$validate_dns3" ]
									then
										incorrect=no
									else
										incorrect=yes
										echo "*** Incorrect value ***"
								fi
					done

		echo -n "Enter First NTP IP address or domain name: "
		read mnu_ntp1
		echo -n "Enter Second NTP IP address or domain name: "
		read mnu_ntp2
		echo -n "Enter Third NTP IP address or domain name: "
		read mnu_ntp3
		echo -n "Enter Fourth NTP IP address or domain name: "
		read mnu_ntp4
		incorrect=yes
		echo -n "Enter time zone (Example, Europe/Moscow): "
		read mnu_timezone
		echo -n "Enter local date (Example, 2022-01-01 14:00:00): "
		read mnu_local_time
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
				5)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[5] Run ping utility                                "
		echo "----------------------------------------------------"
		echo -n "Enter target IP address or domain name: "
		read mnu_ping
			ping $mnu_ping -w 10 -c 5 -i 1
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
				6)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[6] Run traceroute utility                          "
		echo "----------------------------------------------------"
		echo -n "Enter target IP address or domain name: "
		read mnu_traceroute
			traceroute $mnu_traceroute -n
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
				7)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[7] Check configuration and connection status       "
		echo "----------------------------------------------------"
		echo "---------------- Current configuration -------------"

######################Eth0 Settings##################################################################################

			curr_eth_dhcp=`cat /etc/network/interfaces | grep iface | grep eth0 | awk -F " " '{print $4}'`
			#curr_eth_address=`ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
			#curr_eth_subnet=`ifconfig eth0 | grep 'inet addr:' | cut -d: -f4 | awk '{ print $1}'`
			curr_eth_address=`ifconfig eth0 | grep 'inet' | cut -d: -f2 | awk '{ print $2}'`
			curr_eth_subnet=`ifconfig eth0 | grep 'inet' | cut -d: -f4 | awk '{ print $4}'`
			curr_eth_gateway=`route -n | grep eth0 | grep 0.0.0.0 | grep UG | head -n1 | awk '{print $2}'`

######################Wlan0 Settings#################################################################################

			curr_wifi_enable=`cat /etc/network/interfaces 2>/dev/null | grep wpa | wc -l | sed 's/2/Enabled/g' | sed 's/0/Disabled/g'`
			curr_wifi_ssid=`cat /etc/network/interfaces 2>/dev/null | grep ssid | awk -F " " '{print $2}' | sed 's/"//g'`
			curr_wifi_key=`cat /etc/network/interfaces 2>/dev/null | grep psk | awk -F " " '{print $2}' | sed 's/"//g'`
			#curr_wifi_address=`ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
			#curr_wifi_subnet=`ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f4 | awk '{ print $1}'`
			curr_wifi_address=`ifconfig wlan0 | grep 'inet' | cut -d: -f2 | awk '{ print $2}'`
			curr_wifi_subnet=`ifconfig wlan0 | grep 'inet' | cut -d: -f4 | awk '{ print $4}'`
			curr_wifi_gateway=`route -n | grep wlan0 | grep 0.0.0.0 | grep UG | head -n1 | awk '{print $2}'`

######################BE CMS Manager Settings#######################################################################

			#curr_mgr_address=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote" | awk -F " " '{print $2}'`
			#curr_vpn_port=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote" | awk -F " " '{print $3}'`
			curr_mgr_address=`cat /etc/openvpn/client.conf 2>/dev/null | awk -F " " '/remote / {print $2}'`
			curr_vpn_port=`cat /etc/openvpn/client.conf 2>/dev/null | awk -F " " '/remote / {print $3}'`
			curr_mgr_tunnel_ip=`cat /usr/local/cms/config/soap 2>/dev/null | grep "soap_host" | awk -F "=" '{print $2}'`
			curr_control_url=`cat /usr/local/cms/config/apl_manager.conf | grep url | awk -F " " '{print $3}'`
			curr_context=`cat /usr/local/cms/config/apl_manager.conf | grep context | awk -F " " '{print $3}'`
			curr_vpn_status=`ifconfig | grep "tun0" | awk -F " " '{print $1}' | sed 's/tun0/'Connected'/g'`
			curr_app_active_if=`route -n | grep 0.0.0.0 | grep UG | head -n1 | awk -F " " '{print $8}' | sed 's/eth0/Ethernet/g' | sed 's/wlan0/Wi-Fi/g' | sed 's/ppp0/Modem/g'`

######################DNS Settings##################################################################################

			#curr_dns1=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $2}'`
			#curr_dns2=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $4}'`
			#curr_dns3=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $6}'`
			curr_dns1=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $1}'`
			curr_dns2=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $2}'`
			curr_dns3=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $3}'`

######################NTP Settings##################################################################################

			#curr_ntp1=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $2}'`
			#curr_ntp2=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $5}'`
			#curr_ntp3=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $8}'`
			#curr_ntp4=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $11}'`
			curr_ntp1=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $1}'`
			curr_ntp2=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $2}'`
			curr_ntp3=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $3}'`
			curr_ntp4=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $4}'`

######################APL Settings###################################################################################

			curr_os_ver=`apt-cache show apl-system-software | grep Version | awk -F ": " '{print $2}'`
			curr_apl_sn_led=`cat /usr/local/cms/config/apl_serial`
			curr_apl_sn="F$curr_apl_sn_led"
			curr_apl_model=`cat /usr/local/cms/config/apl_model`

######################Additional Devices Settings####################################################################

			#curr_gsm_status=`lsusb | grep GSM | awk -F " " '{print $11}' | sed 's/E398/'Installed'/g'`
			curr_gsm_status=`lsusb | grep Modem | awk -F " " '{print $11}' | sed 's/Networkcard/'Installed'/g'`
			# TODO Need to plug in web-cam and weather board and test them properly
			curr_weatherboard_status=`ls /dev/ | grep "i2c-1" | sed 's/i2c-1/'Installed'/g'`
			curr_cam_status=`ls /dev/ | grep "video0" | sed 's/video0/'Installed'/g'`

######################Netmon Settings################################################################################

			curr_netmon_hosts=`cat /usr/local/cms/config/netfailover.conf | grep netmon_hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`
			curr_netmon_timeout=`cat /usr/local/cms/config/netfailover.conf | grep netmon_timeout | awk -F "=" '{ print $2}' | sed 's/"/''/g' | awk '{ print $1}'`
			curr_netmon_packets=`cat /usr/local/cms/config/netfailover.conf | grep netmon_packets | awk -F "=" '{ print $2}'`
			curr_netmon_interval=`cat /usr/local/cms/config/netfailover.conf | grep netmon_interval | awk -F "=" '{ print $2}'`
			#curr_netfw_interface_pri=`cat /usr/local/cms/config/netfailover.conf | grep ints | awk -F "=" '{ print $2}' | sed 's/"/''/g' | sed 's/eth0 ppp0 wlan0/Ethernet, GSM, Wi-Fi/g' | sed 's/eth0 wlan0 ppp0/Ethernet, Wi-Fi, GSM/g' | sed 's/ppp0 eth0 wlan0/GSM, Ethernet, Wi-Fi/g' | sed 's/ppp0 wlan0 eth0/GSM, Wi-Fi, Ethernet/g' | sed 's/wlan0 ppp0 eth0/Wi-Fi, GSM, Ethernet/g' | sed 's/wlan0 eth0 ppp0/Wi-Fi, GSM, Ethernet/g'`
			curr_netfw_interface_pri=`cat /usr/local/cms/config/netfailover.conf | grep ints | awk -F "=" '{ print $2}' | sed 's/"/''/g' | sed 's/eth0 ppp0 wlan0/Ethernet, Modem, Wi-Fi/g' | sed 's/eth0 wlan0 ppp0/Ethernet, Wi-Fi, Modem/g' | sed 's/ppp0 eth0 wlan0/Modem, Ethernet, Wi-Fi/g' | sed 's/ppp0 wlan0 eth0/Modem, Wi-Fi, Ethernet/g' | sed 's/wlan0 ppp0 eth0/Wi-Fi, Modem, Ethernet/g' | sed 's/wlan0 eth0 ppp0/Wi-Fi, Modem, Ethernet/g'`
			curr_netfw_hosts=`cat /usr/local/cms/config/netfailover.conf | grep ^hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`

######################Time & Date Settings###########################################################################

			#curr_timezone=`timedatectl | grep Timezone | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
			curr_timezone=`timedatectl | grep "Time zone" | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
			curr_local_time=`timedatectl | grep "Local time" | awk -F " " '{print $4 " " $5}'`

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Ethernet settings ***"
			if [ "$curr_eth_dhcp" = "dhcp" ]
				then
					echo "Ethernet DHCP client:           enabled"
				else
					echo "Ethernet DHCP client:           disabled"
			fi
		echo "Ethernet IP address:            $curr_eth_address"
		echo "Ethernet subnet mask:           $curr_eth_subnet"
		echo "Ethernet default gateway:       $curr_eth_gateway"

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Wi-Fi settings ******"
			if [ "$curr_wifi_enable" = "Enabled" ]
				then
					echo "Wi-Fi inteface:             	enabled"
					echo "Wi-Fi IP address:           	$curr_wifi_address"
					echo "Wi-Fi subnet mask:          	$curr_wifi_subnet"
					echo "Wi-Fi default gateway:      	$curr_wifi_gateway"
					echo "Wi-Fi SSID:                 	$curr_wifi_ssid"
					echo "Wi-Fi KEY:                  	$curr_wifi_key"
				else
					echo "Wi-Fi inteface:             	disabled"
			fi

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Global Settings ****"
		echo "CMS Manager VPN address:        $curr_mgr_address"
		echo "CMS Manager Tunnel IP address:  $curr_mgr_tunnel_ip"
		echo "VPN port:                       $curr_vpn_port"
		echo "Control URL:                    $curr_control_url"
		echo "Context:                        $curr_context"
		echo "First DNS IP address:           $curr_dns1"
		echo "Second DNS IP address:          $curr_dns2"
		echo "Third DNS IP address:           $curr_dns3"
		echo "First NTP IP address:           $curr_ntp1"
		echo "Second NTP IP address:          $curr_ntp2"
		echo "Third NTP IP address:           $curr_ntp3"
		echo "Fourth NTP IP address:          $curr_ntp4"

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Failover Settings ***"
		echo "Netfailover interface priority:  $curr_netfw_interface_pri"
		echo "Netfailover hosts:               $curr_netfw_hosts"
		echo "Netmon hosts:                    $curr_netmon_hosts"
		echo "Netmon timeout:                  $curr_netmon_timeout"
		echo "Netmon packets:                  $curr_netmon_packets"
		echo "Netmon interval:                 $curr_netmon_interval"

###################################################################################################################################################################################################

		echo "---------------- Pending configuration -------------"
		echo "*************************"
		echo "*** Ethernet settings ***"
			if [ "$mnu_eth_dhcp" = "Yes" ] || [ "$mnu_eth_dhcp" = "yes" ] || [ "$mnu_eth_dhcp" = "Y" ] || [ "$mnu_eth_dhcp" = "y" ] || [ "$mnu_eth_dhcp" = "YES" ]
				then
					echo "Ethernet DHCP client:           enabled"
				else
					echo "Ethernet IP address:            $mnu_eth_address"
					echo "Ethernet subnet mask:           $mnu_eth_subnet"
					echo "Ethernet default gateway:       $mnu_eth_gateway"
			fi

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Wi-Fi settings ******"
			if [ -n "$mnu_wifi_enable" ]
				then
					if [ "$mnu_wifi_enable" = "Yes" ] || [ "$mnu_wifi_enable" = "yes" ] || [ "$mnu_wifi_enable" = "Y" ] || [ "$mnu_wifi_enable" = "y" ] || [ "$mnu_wifi_enable" = "YES" ]
						then
							echo "Wi-Fi inteface:                 enabled"
							echo "Wi-Fi SSID:                     $mnu_wifi_ssid"
							echo "Wi-Fi KEY:                      $mnu_wifi_key"
						else
							echo "Wi-Fi inteface:                 disabled"
					fi
			fi

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Global settings *****"
		echo "CMS Manager VPN address:        $mnu_mgr_address"
		echo "VPN port:                       $mnu_vpn_port"
		echo "CMS Manager Tunnel IP address:  $mnu_mgr_tunnel_ip"
		echo "Control URL:                    $mnu_control_url"
		echo "Context:                        $mnu_context"
		echo "First DNS IP address:           $mnu_dns1"
		echo "Second DNS IP address:          $mnu_dns2"
		echo "Third DNS IP address:           $mnu_dns3"
		echo "First NTP IP address:           $mnu_ntp1"
		echo "Second NTP IP address:          $mnu_ntp2"
		echo "Third NTP IP address:           $mnu_ntp3"
		echo "Fourth NTP IP address:          $mnu_ntp4"

###################################################################################################################################################################################################

		echo "----------------- Connection status ----------------"
		echo "MGMT server status:             $curr_vpn_status"
		echo "App active interface:           $curr_app_active_if"
		echo "Timezone:                       $curr_timezone"
		echo "Local Time:                     $curr_local_time"

###################################################################################################################################################################################################

		echo "---------------- System information ----------------"
		echo "Appliance SN:                   BE-$curr_apl_sn"
		echo "Appliance Model:                $curr_apl_model"
		echo "Appliance OS version:           $curr_os_ver"
		echo "GSM Modem status:               $curr_gsm_status"
		echo "Weatherboard status:            $curr_weatherboard_status"
		echo "Camera status:                  $curr_cam_status"

###################################################################################################################################################################################################

		read -p "Press [Enter] key to continue..." readEnterKey
		;;
				8)
			clear

######################Eth0 Settings##################################################################################

			curr_eth_dhcp=`cat /etc/network/interfaces | grep iface | grep eth0 | awk -F " " '{print $4}'`
			#curr_eth_address=`ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
			#curr_eth_subnet=`ifconfig eth0 | grep 'inet addr:' | cut -d: -f4 | awk '{ print $1}'`
			curr_eth_address=`ifconfig eth0 | grep 'inet' | cut -d: -f2 | awk '{ print $2}'`
			curr_eth_subnet=`ifconfig eth0 | grep 'inet' | cut -d: -f4 | awk '{ print $4}'`
			curr_eth_gateway=`route -n | grep eth0 | grep 0.0.0.0 | grep UG | head -n1 | awk '{print $2}'`

######################Wlan0 Settings#################################################################################

			curr_wifi_enable=`cat /etc/network/interfaces 2>/dev/null | grep wpa | wc -l | sed 's/2/Enabled/g' | sed 's/0/Disabled/g'`
			curr_wifi_ssid=`cat /etc/network/interfaces 2>/dev/null | grep ssid | awk -F " " '{print $2}' | sed 's/"//g'`
			curr_wifi_key=`cat /etc/network/interfaces 2>/dev/null | grep psk | awk -F " " '{print $2}' | sed 's/"//g'`
			#curr_wifi_address=`ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
			#curr_wifi_subnet=`ifconfig wlan0 2>/dev/null | grep 'inet addr:' | cut -d: -f4 | awk '{ print $1}'`
			curr_wifi_address=`ifconfig wlan0 | grep 'inet' | cut -d: -f2 | awk '{ print $2}'`
			curr_wifi_subnet=`ifconfig wlan0 | grep 'inet' | cut -d: -f4 | awk '{ print $4}'`
			curr_wifi_gateway=`route -n | grep wlan0 | grep 0.0.0.0 | grep UG | head -n1 | awk '{print $2}'`

######################BE CMS Manager Settings#######################################################################

			#curr_mgr_address=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote" | awk -F " " '{print $2}'`
			#curr_vpn_port=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote" | awk -F " " '{print $3}'`
			curr_mgr_address=`cat /etc/openvpn/client.conf 2>/dev/null | awk -F " " '/remote / {print $2}'`
			curr_vpn_port=`cat /etc/openvpn/client.conf 2>/dev/null | awk -F " " '/remote / {print $3}'`
			curr_mgr_tunnel_ip=`cat /usr/local/cms/config/soap 2>/dev/null | grep "soap_host" | awk -F "=" '{print $2}'`
			curr_control_url=`cat /usr/local/cms/config/apl_manager.conf | grep url | awk -F " " '{print $3}' | awk -F "/" '{print $3}'`
			curr_context=`cat /usr/local/cms/config/apl_manager.conf | grep context | awk -F " " '{print $3}'`
			curr_vpn_status=`ifconfig | grep "tun0" | awk -F " " '{print $1}' | sed 's/tun0/'connected'/g'`
			curr_app_active_if=`route -n | grep 0.0.0.0 | grep UG | head -n1 | awk -F " " '{print $8}' | sed 's/eth0/Ethernet/g' | sed 's/wlan0/Wi-Fi/g' | sed 's/ppp0/Modem/g'`

######################DNS Settings##################################################################################

			#curr_dns1=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $2}'`
			#curr_dns2=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $4}'`
			#curr_dns3=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $6}'`
			curr_dns1=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $1}'`
			curr_dns2=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $2}'`
			curr_dns3=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $3}'`

######################NTP Settings##################################################################################

			#curr_ntp1=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $2}'`
			#curr_ntp2=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $5}'`
			#curr_ntp3=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $8}'`
			#curr_ntp4=`cat /etc/ntp.conf | grep ^server | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $11}'`
			curr_ntp1=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $1}'`
			curr_ntp2=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $2}'`
			curr_ntp3=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $3}'`
			curr_ntp4=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $4}'`

######################APL Settings###################################################################################

			curr_os_ver=`apt-cache show apl-system-software | grep Version | awk -F ": " '{print $2}'`
			curr_apl_sn_led=`cat /usr/local/cms/config/apl_serial`
			curr_apl_sn="F$curr_apl_sn_led"
			curr_apl_model=`cat /usr/local/cms/config/apl_model`

######################Additional Devices Settings####################################################################

			#curr_gsm_status=`lsusb | grep GSM | awk -F " " '{print $11}' | sed 's/E398/'Installed'/g'`
			curr_gsm_status=`lsusb | grep Modem | awk -F " " '{print $11}' | sed 's/Networkcard/'Installed'/g'`
			# TODO Need to plug in web-cam and weather board and test them properly
			curr_weatherboard_status=`ls /dev/ | grep "i2c-1" | sed 's/i2c-1/'Installed'/g'`
			curr_cam_status=`ls /dev/ | grep "video0" | sed 's/video0/'installed'/g'`

######################Netmon Settings################################################################################

			curr_netmon_hosts=`cat /usr/local/cms/config/netfailover.conf | grep netmon_hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`
			curr_netmon_timeout=`cat /usr/local/cms/config/netfailover.conf | grep netmon_timeout | awk -F "=" '{ print $2}' | sed 's/"/''/g' | awk '{ print $1}'`
			curr_netmon_packets=`cat /usr/local/cms/config/netfailover.conf | grep netmon_packets | awk -F "=" '{ print $2}'`
			curr_netmon_interval=`cat /usr/local/cms/config/netfailover.conf | grep netmon_interval | awk -F "=" '{ print $2}'`
			#curr_netfw_interface_pri=`cat /usr/local/cms/config/netfailover.conf | grep ints | awk -F "=" '{ print $2}' | sed 's/"/''/g'`
			curr_netfw_interface_pri=`cat /usr/local/cms/config/netfailover.conf | grep ints | awk -F "=" '{ print $2}' | sed 's/"/''/g' | sed 's/eth0 ppp0 wlan0/Ethernet, Modem, Wi-Fi/g' | sed 's/eth0 wlan0 ppp0/Ethernet, Wi-Fi, Modem/g' | sed 's/ppp0 eth0 wlan0/Modem, Ethernet, Wi-Fi/g' | sed 's/ppp0 wlan0 eth0/Modem, Wi-Fi, Ethernet/g' | sed 's/wlan0 ppp0 eth0/Wi-Fi, Modem, Ethernet/g' | sed 's/wlan0 eth0 ppp0/Wi-Fi, Modem, Ethernet/g'`
			curr_netfw_hosts=`cat /usr/local/cms/config/netfailover.conf | grep ^hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`

######################Time & Date Settings###########################################################################

			#curr_timezone=`timedatectl | grep Timezone | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
			curr_timezone=`timedatectl | grep "Time zone" | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
			curr_local_time=`timedatectl | grep "Local time" | awk -F " " '{print $4 " " $5}'`

###################################################################################################################################################################################################

		if [ -z "$mnu_eth_dhcp" ]
			then
				mnu_eth_dhcp=$curr_eth_dhcp
				if [ "$curr_eth_dhcp" = "dhcp" ]
					then
						mnu_eth_dhcp="Yes"
					else
						mnu_eth_address=$curr_eth_address
						mnu_eth_subnet=$curr_eth_subnet
						mnu_eth_gateway=$curr_eth_gateway
				fi
		fi

		if [ -z "$mnu_dns1" ]
			then
				mnu_dns1=$curr_dns1
				mnu_dns2=$curr_dns2
				mnu_dns3=$curr_dns3
		fi

		if [ -z "$mnu_ntp1" ]
			then
				mnu_ntp1=$curr_ntp1
				mnu_ntp2=$curr_ntp2
				mnu_ntp3=$curr_ntp3
				mnu_ntp4=$curr_ntp4
		fi

		if [ -z "$mnu_mgr_address" ]
			then
				mnu_mgr_address=$curr_mgr_address
		fi

		if [ -z "$mnu_mgr_tunnel_ip" ]
			then
				mnu_mgr_tunnel_ip=$curr_mgr_tunnel_ip
		fi

		if [ -z "$mnu_vpn_port" ]
			then
				mnu_vpn_port=$curr_vpn_port
		fi

		if [ -z "$mnu_control_url" ]
			then
				mnu_control_url=$curr_control_url
		fi

		if [ -z "$mnu_context" ]
			then
				mnu_context=$curr_context
		fi

		if [ "$mnu_wifi_enable" = "Yes" ] || [ "$mnu_wifi_enable" = "yes" ] || [ "$mnu_wifi_enable" = "Y" ] || [ "$mnu_wifi_enable" = "y" ]		
			then
				mnu_wifi_enable="Yes"
			else
				if [ "$mnu_wifi_enable" = "No" ] || [ "$mnu_wifi_enable" = "no" ] || [ "$mnu_wifi_enable" = "N" ] || [ "$mnu_wifi_enable" = "n" ]	
					then
						mnu_wifi_enable="No"
					else
						if [ "$curr_wifi_enable" = "Enabled" ]
							then
								mnu_wifi_enable="Yes"
								mnu_wifi_ssid=$curr_wifi_ssid
								mnu_wifi_key=$curr_wifi_key
						fi
				fi
		fi

		if [ -z "$mnu_timezone" ]
			then
				mnu_timezone=$curr_timezone
		fi

		if [ -z "$mnu_local_time" ]
			then
				mnu_local_time=$curr_local_time
		fi

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[8] Apply configuration and reboot                  "
		echo "----------------------------------------------------"
		echo "---------------- Pending configuration -------------"

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Ethernet settings ***"
			if [ "$mnu_eth_dhcp" = "Yes" ] || [ "$mnu_eth_dhcp" = "yes" ] || [ "$mnu_eth_dhcp" = "Y" ] || [ "$mnu_eth_dhcp" = "y" ] || [ "$mnu_eth_dhcp" = "YES" ]
				then
					echo "Ethernet DHCP client:   	enabled"
				else
					echo "Ethernet IP address:            $mnu_eth_address"
					echo "Ethernet subnet mask:           $mnu_eth_subnet"
					echo "Ethernet default gateway:       $mnu_eth_gateway"
			fi

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Wi-Fi settings ******"
			if [ -n "$mnu_wifi_enable" ]
				then
					if [ "$mnu_wifi_enable" = "Yes" ] || [ "$mnu_wifi_enable" = "yes" ] || [ "$mnu_wifi_enable" = "Y" ] || [ "$mnu_wifi_enable" = "y" ] || [ "$mnu_wifi_enable" = "YES" ]
						then
							echo "Wi-Fi inteface:                 enabled"
							echo "Wi-Fi SSID:                     $mnu_wifi_ssid"
							echo "Wi-Fi KEY:                      $mnu_wifi_key"
						else
							echo "Wi-Fi inteface:                 disabled"
					fi
			fi

###################################################################################################################################################################################################

		echo "*************************"
		echo "*** Global settings *****"
		echo "CMS Manager VPN address:        $mnu_mgr_address"
		echo "VPN port:                       $mnu_vpn_port"
		echo "CMS Manager Tunnel IP address:  $mnu_mgr_tunnel_ip"
		echo "Control URL:             http://$mnu_control_url"/
		echo "Context:                        $mnu_context"
		echo "First DNS IP address:           $mnu_dns1"
		echo "Second DNS IP address:          $mnu_dns2"
		echo "Third DNS IP address:           $mnu_dns3"
		echo "First NTP IP address:           $mnu_ntp1"
		echo "Second NTP IP address:          $mnu_ntp2"
		echo "Third NTP IP address:           $mnu_ntp3"
		echo "Fourth NTP IP address:          $mnu_ntp4"
		echo "Timezone:                       $mnu_timezone"
		echo "Local Time:                     $mnu_local_time"
		echo "--------------------------------------------------"
		echo -n "Do you want apply this configuration? [Yes/No]: "
		read mnu_apply_config
			if [ "$mnu_apply_config" = "Yes" ] || [ "$mnu_apply_config" = "yes" ] || [ "$mnu_apply_config" = "Y" ] || [ "$mnu_apply_config" = "y" ] || [ "$mnu_apply_config" = "YES" ]
				then
					echo "Write configuration..."

###################### Network configuration###########################################################

			if [ "$mnu_eth_dhcp" = "Yes" ]
				then
					cat /usr/local/cms/config/template.network.eth0.dhcp > /etc/network/interfaces
				else
					cat /usr/local/cms/config/template.network.eth0.static | sed 's/ETH_ADDR/'"$mnu_eth_address"'/g' | sed 's/ETH_MASK/'"$mnu_eth_subnet"'/g' | sed 's/ETH_GATEWAY/'"$mnu_eth_gateway"'/g' > /etc/network/interfaces
			fi

			if [ "$mnu_wifi_enable" = "Yes" ]
				then
					cat /usr/local/cms/config/template.network.wifi0.dhcp | sed 's/SSID/'$mnu_wifi_ssid'/g' | sed 's/KEY/'$mnu_wifi_key'/g'  >> /etc/network/interfaces
			fi

##################### VPN and SOAP configuration######################################################

			#cat /usr/local/cms/config/template.openvpn.ca.crt > /etc/openvpn/ca.crt
			cat /usr/local/cms/config/template.openvpn.tun0-add-route.sh > /etc/openvpn/tun0-add-route.sh
			chmod 755 /etc/openvpn/tun0-add-route.sh
			cat /usr/local/cms/config/template.openvpn.conf | sed 's/MGR_ADDRESS/'"$mnu_mgr_address"'/g' | sed 's/VPN_PORT/'"$mnu_vpn_port"'/g' > /etc/openvpn/client.conf
			cat /usr/local/cms/config/template.apl_manager.conf | sed 's/CONTROL_URL/'"$mnu_control_url"'/g' | sed 's/CONTEXT/'"$mnu_context"'/g' | sed 's/SERIAL/'"$curr_apl_sn"'/g' > /usr/local/cms/config/apl_manager.conf
			cat /usr/local/cms/config/template.soap | sed 's/SOAP_HOST/'"$mnu_mgr_tunnel_ip"'/g' > /usr/local/cms/config/soap

##################### DNS and NTP configuration#######################################################

			cat /usr/local/cms/config/template.dhclient.conf | sed 's/DNS1/'"$mnu_dns1"'/g' | sed 's/DNS2/'"$mnu_dns2"'/g' | sed 's/DNS3/'"$mnu_dns3"'/g' > /etc/dhcp/dhclient.conf
			#cat /usr/local/cms/config/template.ntp.conf | sed 's/NTP1/'"$mnu_ntp1"'/g' | sed 's/NTP2/'"$mnu_ntp2"'/g' | sed 's/NTP3/'"$mnu_ntp3"'/g' | sed 's/NTP4/'"$mnu_ntp4"'/g' > /etc/ntp.conf
			cat /usr/local/cms/config/template.timesyncd.conf | sed 's/NTP1/'"$mnu_ntp1"'/g' | sed 's/NTP2/'"$mnu_ntp2"'/g' | sed 's/NTP3/'"$mnu_ntp3"'/g' | sed 's/NTP4/'"$mnu_ntp4"'/g' > /etc/systemd/timesyncd.conf
			cat /usr/local/cms/config/template.resolved.conf | sed 's/DNS1/'"$mnu_dns1"'/g' | sed 's/DNS2/'"$mnu_dns2"'/g' | sed 's/DNS3/'"$mnu_dns3"'/g' > /etc/systemd/resolved.conf
			systemctl restart systemd-resolved.service
			systemctl restart systemd-timesyncd.service

##################### Time Configuration##############################################################

			timedatectl set-timezone $mnu_timezone
			#timedatectl set-time "$mnu_local_time" #Failed to set time: Automatic time synchronization is enabled

##################### Hostname & Hosts Configuration##################################################

			cat /usr/local/cms/config/template.hostname | sed 's/APL_SERIAL/'"$curr_apl_sn"'/g' > /etc/hostname
			cat /usr/local/cms/config/template.hosts | sed 's/APL_SERIAL/'"$curr_apl_sn"'/g' > /etc/hosts

###################################################################################################################################################################################################

			sleep 1
			echo -n "Reboot..."
			sleep 1
			sudo reboot
			exit 0
			fi
		;;
				9)
			clear

###################################################################################################################################################################################################

		echo "----------------------------------------------------"
		echo "[9] Discard changes and exit                        "
		echo "----------------------------------------------------"
		echo -n "Do you want a exit? [Yes/No]: "
		read mnu_exit
			if [ "$mnu_exit" = "Yes" ] || [ "$mnu_exit" = "yes" ] || [ "$mnu_exit" = "Y" ] || [ "$mnu_exit" = "y" ] || [ "$mnu_exit" = "YES" ]
				then
					echo "Exit..."
					sleep 1
					exit 0
			fi
		;;
				*)
		echo "Error: Invalid option..."
		read -p "Press [Enter] key to continue..." readEnterKey
		;;
		esac

done
###################################################################################################################################################################################################

