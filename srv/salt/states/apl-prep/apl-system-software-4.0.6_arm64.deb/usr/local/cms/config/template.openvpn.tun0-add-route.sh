#!/bin/bash

/sbin/ip route add 192.168.128.1/32 via 192.168.192.1 dev tun0

