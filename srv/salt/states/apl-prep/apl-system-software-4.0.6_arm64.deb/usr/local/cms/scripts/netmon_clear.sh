#! /bin/bash

cat /dev/null > /var/log/netmon.log
