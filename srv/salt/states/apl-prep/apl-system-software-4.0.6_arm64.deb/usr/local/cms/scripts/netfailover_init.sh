# netfailover_init
#source /usr/local/cms/config/netfailover.conf
i=1
for int in $ints;do
# echo $i
 ip route flush table $i
 ip rule show | grep "lookup $i" | awk -F ":" '{print $1}' | xargs -r -L1 ip rule del prio
 dfgw=`route -n | grep "$int" | awk '/ UG / {print $2}' | head -n1`
 intip=`ifconfig $int | awk '/inet addr:/ {print $2}' | sed -e s/addr://g`
 [ x"$intip" = "x" ] && continue
# echo $int
# echo $dfgw
# echo $intip
 for host in $hosts $netmon_hosts;do
  ip route add $host via $dfgw dev $int table $i
  ip rule add from $intip to $host table $i prio $i
 done
 let i=$i+1
done