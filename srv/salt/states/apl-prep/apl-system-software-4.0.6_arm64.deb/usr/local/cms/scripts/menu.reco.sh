#!/bin/bash

# capture CTRL+C, CTRL+Z and quit singles using the trap
trap '' SIGINT
trap '' usb0
trap '' SIGTSTP

# Create infinite while loop
while true
do
	clear
	# display menu
		echo "----------------------------------------------------"
		echo "                                                    "
		echo "                BUSINESS ECOSYSTEMS                 "
		echo "           CMS APPLIANCE RECOVERY WIZARD        	  "
		echo "                                                    "
		echo "----------------------------------------------------"
		echo "[1] Change password for cms                         "
		echo "[2] Exit                                            "
		echo "----------------------------------------------------"

	# get input from the user
		read -p "Enter your choice [0-2]:" choice

	# make decision using case..in..esac
		case $choice in
				1)
					clear
					echo "----------------------------------------------------"
					echo "[1] Change password for cms                         "
					echo "----------------------------------------------------"
					echo -n
					passwd cms
					read -p "Press [Enter] key to continue..." readEnterKey
					;;
				2)
					clear
					echo "----------------------------------------------------"
					echo "[2] Exit                                            "
					echo "----------------------------------------------------"
					echo -n "Do you want a exit? [Yes/No]: "
					read mnu_exit
##############################################################################################################################################################################
						if [ "$mnu_exit" = "Yes" ] || [ "$mnu_exit" = "yes" ] || [ "$mnu_exit" = "Y" ] || [ "$mnu_exit" = "y" ] || [ "$mnu_exit" = "YES" ]
							then
								echo "Exit..."
							sleep 1
							exit 0
						fi
						;;
				*)
					echo "Error: Invalid option..."
					read -p "Press [Enter] key to continue..." readEnterKey
					;;
		esac

done
