Check if weatherboard is installed correctly (https://wiki.odroid.com/common/application_note/software/weather_board#tab__odroid-c4)
Check if i2c is worked correctly (https://wiki.odroid.com/odroid-n2/application_note/gpio/i2c):

apt install i2c-tools device-tree-compiler
i2cdetect -y -r 0
i2cdetect -y -r 1

uname -r
nano /media/boot/config.ini
ls /dev/i2c*

fdtget /media/boot/amlogic/meson64_odroidc4.dtb /soc/cbus@ffd00000/i2c@1d000 status
fdtget /media/boot/amlogic/meson64_odroidc4.dtb /soc/cbus@ffd00000/i2c@1c000 status

ll /sys/bus/i2c/devices

fdtput -t s /media/boot/amlogic/meson64_odroidc4.dtb /soc/cbus@ffd00000/i2c@1d000 status okay
fdtput -t s /media/boot/amlogic/meson64_odroidc4.dtb /soc/cbus@ffd00000/i2c@1c000 status okay

i2cdetect -y -r 0
i2cdetect -y -r 1
