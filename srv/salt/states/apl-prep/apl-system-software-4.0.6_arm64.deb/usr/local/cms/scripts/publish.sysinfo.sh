#!/bin/bash

soap_host=`cat /usr/local/cms/config/soap | grep "soap_host" | awk -F "=" '{print $2}'`
ping -q -c2 $soap_host > /dev/null

if [ $? -eq 0 ]
then
		vpn_status="1"
else
		vpn_status="0"
fi

if [ -f /usr/local/cms/config/soap ] && [ "$vpn_status" = "1" ]
		then
	#sudo /usr/local/cms/bin/ledcontrol set led vpn flash
######## SYSTEM PARAMETERS

	sys_sn_led=`cat /usr/local/cms/config/apl_serial`
	sys_sn="F$sys_sn_led"
	sys_model=`cat /usr/local/cms/config/apl_model`
	sys_ver=`apt-cache show apl-system-software | grep Version | awk -F ": " '{print $2}'`
	sys_lock=`cat /usr/local/cms/config/syslock`
	config_ver=`uptime -p | awk -F "up" '{print $2}'`
	app_port_count=`cat /sys/kernel/debug/usb/devices | grep "Product=USB2.0 Hub" | wc -l`
	app_active_if=`route -n | grep 0.0.0.0 | grep UG | head -n1 | awk -F " " '{print $8}'`
	control_url=`cat /usr/local/cms/config/apl_manager.conf | grep url | awk -F " " '{print $3}'`
	int4_name=`echo nvpn`
	int6_dhcp_server=`cat /usr/local/cms/config/apl_manager.conf | grep context | awk -F " " '{print $3}'`

######## LTE MODEM

	modem_status=`ifconfig -a | grep "ppp0" | awk -F " " '{print $1}' | sed 's/ppp0/'true'/g'`

	if [ -z "$modem_status" ]
		then
			modem_status="false"
	fi

	#modem_type=`cat /sys/kernel/debug/usb/devices | grep "^S.*HUAWEI HiLink" | awk -F "=" '{print $2}'`
	modem_type=`cat /sys/kernel/debug/usb/devices | grep "Product=MOBILE" | awk -F "=" '{print $2}'`
######## WEB CAMERA

	web_cam_status=`ls /dev/ | grep "video0" | sed 's/video0/'true'/g'`

	if [ -z "$web_cam" ]
	then
		web_cam="false"
	fi

######## WEATHERBOARD

#    weatherboard_status=`ls /dev/ | grep "i2c-1" | sed 's/i2c-1/'true'/g'`
#
#    if [ -z "$weatherboard" ]
#      then
#         weatherboard="false"
#    fi

######## VPN CONNECTION

	if [ -z "$vpn_status" ]
		then
			app_vpn_status="false"
	fi

	app_vpn_address=`ifconfig tun0 2>/dev/null | grep 'inet ' | cut -d: -f2 | awk '{ print $2}'`
	mgr_address=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote " | awk -F " " '{print $2}'`
	mgr_vpn_port=`cat /etc/openvpn/client.conf 2>/dev/null | grep "remote " | awk -F " " '{print $3}'`
	mgr_vpn_address=`route -n | grep tun0 | head -n1 | awk -F " " '{print $1}'`

######## INT1 INFO (eth0)

	int1_name=`cat /usr/local/cms/config/int_name.conf | grep int1_name | awk -F "=" '{ print $2}'`
	int1_admin_status=`ifconfig | grep eth0 | awk -F " " '{print $1}' | sed 's/eth0/'true'/g'`
	int1_curr_state=`cat /var/log/netmon.log | grep eth0 | awk -F " " '{print $3}'`
	int1_packet_loss=`cat /var/log/netmon.log | grep eth0 | awk -F " " '{print $4}'`
	int1_avg_delay=`cat /var/log/netmon.log | grep eth0 | awk -F " " '{print $5}'`
	int1_proto=`cat /etc/network/interfaces | grep 'eth0 inet' | awk -F " " '{print $4}'`
	int1_address=`ifconfig eth0 2>/dev/null | grep 'inet ' | cut -d: -f2 | awk '{ print $2}'`
	#int1_netmask=`ifconfig eth0 2>/dev/null | grep 'inet ' | cut -d: -f4 | awk '{ print $2}'`
	int1_netmask=`ifconfig eth0 2>/dev/null | grep 'inet' | cut -d: -f4 | awk '{ print $4}'`
	int1_gateway=`netstat -rn | grep eth0 | grep 0.0.0.0 | awk '{print $2}' | grep -v "0.0.0.0" | head -n1`

######## INT2 INFO (usbnet0)

	int2_name=`cat /usr/local/cms/config/int_name.conf | grep int2_name | awk -F "=" '{ print $2}'`
	int2_admin_status=`ifconfig | grep ppp0 | awk -F " " '{print $1}' | sed 's/ppp0/'true'/g'`
	int2_curr_state=`cat /var/log/netmon.log | grep ppp0 | awk -F " " '{print $3}'`
	int2_packet_loss=`cat /var/log/netmon.log | grep ppp0 | awk -F " " '{print $4}'`
	int2_avg_delay=`cat /var/log/netmon.log | grep ppp0 | awk -F " " '{print $5}'`
	int2_proto=`cat /etc/network/interfaces | grep 'ppp0 inet' | awk -F " " '{print $4}'`
	int2_address=`ifconfig ppp0 2>/dev/null | grep 'inet ' | cut -d: -f2 | awk '{ print $2}'`
	#int2_netmask=`ifconfig ppp0 2>/dev/null | grep 'inet ' | cut -d: -f4 | awk '{ print $2}'`
	int2_netmask=`ifconfig ppp0 2>/dev/null | grep 'inet ' | cut -d: -f4 | awk '{ print $4}'`
	int2_gateway=`netstat -rn | grep ppp0 | grep 0.0.0.0 | awk '{print $2}' | grep -v "0.0.0.0" | head -n1`

######## INT3 INFO (wlan0)

	int3_name=`cat /usr/local/cms/config/int_name.conf | grep int3_name | awk -F "=" '{ print $2}'`
	int3_admin_status=`ifconfig | grep wlan0 | awk -F " " '{print $1}' | sed 's/wlan0/'true'/g'`
	int3_curr_state=`cat /var/log/netmon.log | grep wlan0 | awk -F " " '{print $3}'`
	int3_packet_loss=`cat /var/log/netmon.log | grep wlan0 | awk -F " " '{print $4}'`
	int3_avg_delay=`cat /var/log/netmon.log | grep wlan0 | awk -F " " '{print $5}'`
	int3_proto=`cat /etc/network/interfaces | grep 'wlan0 inet' | awk -F " " '{print $4}'`
	int3_address=`ifconfig wlan0 2>/dev/null | grep 'inet ' | cut -d: -f2 | awk '{ print $2}'`
	#int3_netmask=`ifconfig wlan0 2>/dev/null | grep 'inet ' | cut -d: -f4 | awk '{ print $2}'`
	int3_netmask=`ifconfig wlan0 2>/dev/null | grep 'inet ' | cut -d: -f4 | awk '{ print $4}'`
	int3_gateway=`netstat -rn | grep wlan0 | grep 0.0.0.0 | awk '{print $2}' | grep -v "0.0.0.0" | head -n1`
	int3_metric=`ip route | grep default | grep wlan0 | awk '{print $7}'`
	int3_ssid=`cat /etc/network/interfaces | grep wpa-ssid | awk '{ print $2}' | sed 's/"/''/g'`
	int3_key=`cat /etc/network/interfaces | grep wpa-psk | awk '{ print $2}' | sed 's/"/''/g'`
	int3_encryption=`cat /usr/local/cms/config/wifi_settings | grep encryption | awk -F "=" '{ print $2}'`
	int3_mode=`cat /usr/local/cms/config/wifi_settings | grep mode | awk -F "=" '{ print $2}'`

######## NETFAILOVER & NETMON SETTINGS

	netmon_hosts=`cat /usr/local/cms/config/netfailover.conf | grep netmon_hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`
	netmon_timeout=`cat /usr/local/cms/config/netfailover.conf | grep netmon_timeout | awk -F "=" '{ print $2}' | sed 's/"/''/g' | awk '{ print $1}'`
	netmon_packets=`cat /usr/local/cms/config/netfailover.conf | grep netmon_packets | awk -F "=" '{ print $2}'`
	netmon_interval=`cat /usr/local/cms/config/netfailover.conf | grep netmon_interval | awk -F "=" '{ print $2}'`
	netfw_interface_pri=`cat /usr/local/cms/config/netfailover.conf | grep ints | awk -F "=" '{ print $2}' | sed 's/"/''/g'`
	netfw_hosts=`cat /usr/local/cms/config/netfailover.conf | grep ^hosts | awk -F "=" '{ print $2}' | sed 's/"/''/g'`

######## DNS & NTP SETTINGS

	#dns1=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $2}'`
	#dns2=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $4}'`
	#dns3=`cat /etc/resolv.conf | grep nameserver | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{ print $6}'`
	dns1=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $1}'`
	dns2=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $2}'`
	dns3=`cat /etc/systemd/resolved.conf | grep -w 'DNS' | sed 's/DNS=/''/g' | awk -F " " '{ print $3}'`
	#ntp1=`cat /etc/ntp.conf | grep server | sed ':a;N;$!ba;s/\n/ /g' | awk '{ print $22}'`
	#ntp2=`cat /etc/ntp.conf | grep server | sed ':a;N;$!ba;s/\n/ /g' | awk '{ print $24}'`
	#ntp3=`cat /etc/ntp.conf | grep server | sed ':a;N;$!ba;s/\n/ /g' | awk '{ print $26}'`
	#ntp4=`cat /etc/ntp.conf | grep server | sed ':a;N;$!ba;s/\n/ /g' | awk '{ print $28}'`
	ntp1=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $1}'`
	ntp2=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $2}'`
	ntp3=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $3}'`
	ntp4=`cat /etc/systemd/timesyncd.conf | grep -w 'NTP' | sed 's/NTP=/''/g' | awk -F " " '{ print $4}'`
	
######## WEATHERBOARD

#	temperature=`sudo /usr/local/cms/bin/weather_board | grep temperature | awk -F ":" '{print $2}'`
temperature=`cat /tmp/weather.txt | grep "temperature" | sed 's/'" 'C"'/''/g' | awk -F ":" '{print $2}'`
#    humidity=`sudo /usr/local/cms/bin/weather_board | grep humidity | awk -F ":" '{print $2}'`
humidity=`cat /tmp/weather.txt | grep "humidity" | sed 's/'" %"'/''/g' | awk -F ":" '{print $2}'`
#	pressure=`sudo /usr/local/cms/bin/weather_board | grep pressure | awk -F ":" '{print $2}'`
pressure=`cat /tmp/weather.txt | grep "pressure" | sed 's/'" hPa"'/''/g' | awk -F ":" '{print $2}'`
#    altitude=`sudo /usr/local/cms/bin/weather_board | grep altitude | awk -F ":" '{print $2}'`
altitude=`cat /tmp/weather.txt | grep "altitude" | sed 's/'" m"'/''/g' | awk -F ":" '{print $2}'`
#	temperature=`sudo snmpget -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.8800.1.1.2.1 | awk -F ": " '{print $2}'`
#	io1=`sudo snmpget -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.8900.1.1.2.1 | awk -F ": " '{print $2}'`
#	io2=`sudo snmpget -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.8900.1.1.2.2 | awk -F ": " '{print $2}'`
#	io3=`sudo snmpget -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.8900.1.1.2.3 | awk -F ": " '{print $2}'`
#	io4=`sudo snmpget -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.8900.1.1.2.4 | awk -F ": " '{print $2}'`

######## COM PORT MAPPING

	cat /sys/kernel/debug/usb/devices | grep "^T.*\|^P:\|USB-Serial Controller\|USB2.0-Ser\|Cisco USB Console\|FT232R USB UART" | sed ':a;N;$!ba;s/\n/ /g' | sed "s/T:/\nT:/g" | awk -F " " '{print $3, $4, $5, $13, $14}' | cat /sys/kernel/debug/usb/devices | grep "^T.*\|^P:\|USB-Serial Controller\|USB2.0-Ser\|Cisco USB Console\|FT232R USB UART" | sed ':a;N;$!ba;s/\n/ /g' | sed "s/T:/\nT:/g" \
	| grep "Product=USB-Serial Controller\|USB2.0-Ser\|Cisco USB Console\|FT232R USB UART" | sed "s/=/\ /g" | awk -F " " '{print $5$9}' | sed ':a;N;$!ba;s/\n/ /g' > /tmp/usb_serial_state

	com1_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $1}'`
	com1_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $1}'`
	com2_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $2}'`
	com2_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $2}'`
	com3_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $3}'`
	com3_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $3}'`
	com4_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $4}'`
	com4_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $4}'`
	com5_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $5}'`
	com5_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $5}'`
	com6_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $6}'`
	com6_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $6}'`
	com7_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $7}'`
	com7_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $7}'`
	com8_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $8}'`
	com8_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $8}'`
	com9_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $9}'`
	com9_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $9}'`
	com10_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $10}'`
	com10_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $10}'`
	com11_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $11}'`
	com11_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $11}'`
	com12_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $12}'`
	com12_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $12}'`
	com13_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $13}'`
	com13_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $13}'`
	com14_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $14}'`
	com14_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $14}'`
	com15_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $15}'`
	com15_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $15}'`
	com16_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $16}'`
	com16_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $16}'`
	com17_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $17}'`
	com17_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $17}'`
	com18_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $18}'`
	com18_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $18}'`
	com19_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $19}'`
	com19_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $19}'`
	com20_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $20}'`
	com20_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $20}'`
	com21_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $21}'`
	com21_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $21}'`
	com22_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $22}'`
	com22_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $22}'`
	com23_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $23}'`
	com23_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $23}'`
	com24_name=`ls /dev/ | grep ttyUSB | sed ':a;N;$!ba;s/\n/ /g' | awk -F " " '{print $24}'`
	com24_phy=`cat /tmp/usb_serial_state | awk -F " " '{print $24}'`

######## PDU INFORMATION

#	pdu1_sn_fw=`cat /usr/local/cms/config/pdu_serial`
#	pdu1_sn="E$pdu1_sn_fw"
#	pdu1_model=`cat /usr/local/cms/config/pdu_model | sed 's/HA-R8/'PDU-HA-R8'/g' | sed 's/MA-R8/'PDU-MA-R8'/g' | sed 's/LA-P4/'PDU-LA-P4'/g' | sed 's/LA-P2/'PDU-LA-P2'/g' | sed 's/IOCTL failed: Bad file descriptor/''/g'`
	#pdu1_firmware_version=`/usr/local/cms/bin/pducontrol pdu_id 1 get fw_version | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu1_outlet1_status=`sudo snmpget -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.5800.3.1.3.1 | awk -F ": " '{print $2}'`
#        pdu1_outlet2_status=`sudo snmpget -v1 -c becsys 192.168.88.100 1.3.6.1.4.1.25728.5800.3.1.3.2 | awk -F ": " '{print $2}'`
#	pdu1_outlet_status="$pdu1_outlet1_status $pdu1_outlet2_status"
	#pdu1_outlet_status=`/usr/local/cms/bin/pducontrol pdu_id 1 get bulk | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu1_conn_type=`cat /usr/local/cms/config/pdu.conf | grep pdu1_conn_type | awk -F "=" '{print $2}'`
#        pdu1_mode=`echo no`
#	pdu1_lockdown=`/usr/local/cms/bin/pducontrol pdu_id 1 get lockdown | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu1_slow_start=`/usr/local/cms/bin/pducontrol pdu_id 1 get slow_start | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu1_features="$pdu1_mode,$pdu1_lockdown,$pdu1_slow_start,"
#	pdu2_sn_fw=`/usr/local/cms/bin/pducontrol pdu_id 2 get serial | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu2_sn="E$pdu2_sn_fw"
#	pdu2_model=`/usr/local/cms/bin/pducontrol pdu_id 2 get model | sed 's/HA-R8/'PDU-HA-R8'/g' | sed 's/MA-R8/'PDU-MA-R8'/g' | sed 's/LA-P4/'PDU-LA-P4'/g' | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu2_firmware_version=`/usr/local/cms/bin/pducontrol pdu_id 2 get fw_version | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu2_outlet_status=`/usr/local/cms/bin/pducontrol pdu_id 2 get bulk | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu2_conn_type=`cat /usr/local/cms/config/pdu.conf | grep pdu2_conn_type | awk -F "=" '{print $2}'`
#    pdu2_mode=`echo no`
#	pdu2_lockdown=`/usr/local/cms/bin/pducontrol pdu_id 2 get lockdown | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu2_slow_start=`/usr/local/cms/bin/pducontrol pdu_id 2 get slow_start | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu2_features="$pdu2_mode,$pdu2_lockdown,$pdu2_slow_start,"
#	pdu3_sn_fw=`/usr/local/cms/bin/pducontrol pdu_id 3 get serial | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu3_sn="E$pdu3_sn_fw"
#	pdu3_model=`/usr/local/cms/bin/pducontrol pdu_id 3 get model | sed 's/HA-R8/'PDU-HA-R8'/g' | sed 's/MA-R8/'PDU-MA-R8'/g' | sed 's/LA-P4/'PDU-LA-P4'/g' | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu3_firmware_version=`/usr/local/cms/bin/pducontrol pdu_id 3 get fw_version | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu3_outlet_status=`/usr/local/cms/bin/pducontrol pdu_id 3 get bulk | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu3_conn_type=`cat /usr/local/cms/config/pdu.conf | grep pdu3_conn_type | awk -F "=" '{print $2}'`
#    pdu3_mode=`echo no`
#	pdu3_lockdown=`/usr/local/cms/bin/pducontrol pdu_id 3 get lockdown | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu3_slow_start=`/usr/local/cms/bin/pducontrol pdu_id 3 get slow_start | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu3_features="$pdu3_mode,$pdu3_lockdown,$pdu3_slow_start,"
#	pdu4_sn_fw=`/usr/local/cms/bin/pducontrol pdu_id 4 get serial | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu4_sn="E$pdu4_sn_fw"
#	pdu4_model=`/usr/local/cms/bin/pducontrol pdu_id 4 get model | sed 's/HA-R8/'PDU-HA-R8'/g' | sed 's/MA-R8/'PDU-MA-R8'/g' | sed 's/LA-P4/'PDU-LA-P4'/g' | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu4_firmware_version=`/usr/local/cms/bin/pducontrol pdu_id 4 get fw_version | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu4_outlet_status=`/usr/local/cms/bin/pducontrol pdu_id 4 get bulk | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu4_conn_type=`cat /usr/local/cms/config/pdu.conf | grep pdu4_conn_type | awk -F "=" '{print $2}'`
#    pdu4_mode=`echo no`
#	pdu4_lockdown=`/usr/local/cms/bin/pducontrol pdu_id 4 get lockdown | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu4_slow_start=`/usr/local/cms/bin/pducontrol pdu_id 4 get slow_start | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu4_features="$pdu4_mode,$pdu4_lockdown,$pdu4_slow_start,"
#	pdu5_sn_fw=`/usr/local/cms/bin/pducontrol pdu_id 5 get serial | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu5_sn="E$pdu5_sn_fw"
#	pdu5_model=`/usr/local/cms/bin/pducontrol pdu_id 5 get model | sed 's/HA-R8/'MA-PDU-R8'/g' | sed 's/MA-R8/'HA-PDU-R8'/g' | sed 's/LA-P4/'LA-PDU-P4'/g' | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu5_firmware_version=`/usr/local/cms/bin/pducontrol pdu_id 5 get fw_version | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu5_outlet_status=`/usr/local/cms/bin/pducontrol pdu_id 5 get bulk | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu5_conn_type=`cat /usr/local/cms/config/pdu.conf | grep pdu5_conn_type | awk -F "=" '{print $2}'`
#    pdu5_mode=`echo no`
#	pdu5_lockdown=`/usr/local/cms/bin/pducontrol pdu_id 5 get lockdown | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu5_slow_start=`/usr/local/cms/bin/pducontrol pdu_id 5 get slow_start | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu5_features="$pdu5_mode,$pdu5_lockdown,$pdu5_slow_start,"
#	pdu6_sn_fw=`/usr/local/cms/bin/pducontrol pdu_id 6 get serial | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu6_sn="E$pdu6_sn_fw"
#	pdu6_model=`/usr/local/cms/bin/pducontrol pdu_id 6 get model | sed 's/HA-R8/'PDU-HA-R8'/g' | sed 's/MA-R8/'PDU-MA-R8'/g' | sed 's/LA-P4/'PDU-LA-P4'/g' | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu6_firmware_version=`/usr/local/cms/bin/pducontrol pdu_id 6 get fw_version | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu6_outlet_status=`/usr/local/cms/bin/pducontrol pdu_id 6 get bulk | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu6_conn_type=`cat /usr/local/cms/config/pdu.conf | grep pdu6_conn_type | awk -F "=" '{print $2}'`
#    pdu6_mode=`echo no`
#	pdu6_lockdown=`/usr/local/cms/bin/pducontrol pdu_id 6 get lockdown | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu6_slow_start=`/usr/local/cms/bin/pducontrol pdu_id 6 get slow_start | sed 's/IOCTL failed: Bad file descriptor/''/g'`
#	pdu6_features="$pdu6_mode,$pdu6_lockdown,$pdu6_slow_start,"
	
######## PREPARE XML DOCUMENT

		echo "<s11:Envelope xmlns:s11='http://schemas.xmlsoap.org/soap/envelope/'>" > /tmp/register.xml
		echo "  <s11:Body>" >> /tmp/register.xml
		echo "    <ns1:REGISTERInput xmlns:ns1='http://xmlns.oracle.com/orawsv/CMS/REGISTER'>" >> /tmp/register.xml
		echo "      <ns1:P255_PDU6_ALLOWED_IP-VARCHAR2-IN>$pdu6_allowed_ip</ns1:P255_PDU6_ALLOWED_IP-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P254_PDU6_SNMP_COMM_RW-VARCHAR2-IN>$pdu6_snmp_comm_rw</ns1:P254_PDU6_SNMP_COMM_RW-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P253_PDU6_SNMP_COMM_RO-VARCHAR2-IN>$pdu6_snmp_comm_ro</ns1:P253_PDU6_SNMP_COMM_RO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P252_PDU6_SNMP_VERSION-VARCHAR2-IN>$pdu6_snmp_version</ns1:P252_PDU6_SNMP_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P251_PDU6_GATEWAY-VARCHAR2-IN>$pdu6_gateway</ns1:P251_PDU6_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P250_PDU6_NETMASK-VARCHAR2-IN>$pdu6_netmask</ns1:P250_PDU6_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P249_PDU6_IP_ADDRESS-VARCHAR2-IN>$pdu6_ip_address</ns1:P249_PDU6_IP_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P248_PDU6_INPUT_METER-VARCHAR2-IN>$pdu6_input_meter</ns1:P248_PDU6_INPUT_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P247_PDU6_INPUT_STATUS-VARCHAR2-IN>$pdu6_input_status</ns1:P247_PDU6_INPUT_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P246_PDU6_OUTLET_METER-VARCHAR2-IN>$pdu6_outlet_meter</ns1:P246_PDU6_OUTLET_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P245_PDU6_OUTLET_STATUS-VARCHAR2-IN>$pdu6_outlet_status</ns1:P245_PDU6_OUTLET_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P244_PDU6_CONN_TYPE-VARCHAR2-IN>$pdu6_conn_type</ns1:P244_PDU6_CONN_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P243_PDU6_FEATURES-VARCHAR2-IN>$pdu6_features</ns1:P243_PDU6_FEATURES-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P242_PDU6_FIRMWARE_VERSION-VARCHAR2-IN>$pdu6_firmware_version</ns1:P242_PDU6_FIRMWARE_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P241_PDU6_MODEL-VARCHAR2-IN>$pdu6_model</ns1:P241_PDU6_MODEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P240_PDU6_SN-VARCHAR2-IN>$pdu6_sn</ns1:P240_PDU6_SN-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P239_PDU5_ALLOWED_IP-VARCHAR2-IN>$pdu5_allowed_ip</ns1:P239_PDU5_ALLOWED_IP-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P238_PDU5_SNMP_COMM_RW-VARCHAR2-IN>$pdu5_snmp_comm_rw</ns1:P238_PDU5_SNMP_COMM_RW-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P237_PDU5_SNMP_COMM_RO-VARCHAR2-IN>$pdu5_snmp_comm_ro</ns1:P237_PDU5_SNMP_COMM_RO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P236_PDU5_SNMP_VERSION-VARCHAR2-IN>$pdu5_snmp_version</ns1:P236_PDU5_SNMP_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P235_PDU5_GATEWAY-VARCHAR2-IN>$pdu5_gateway</ns1:P235_PDU5_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P234_PDU5_NETMASK-VARCHAR2-IN>$pdu5_netmask</ns1:P234_PDU5_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P233_PDU5_IP_ADDRESS-VARCHAR2-IN>$pdu5_ip_address</ns1:P233_PDU5_IP_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P232_PDU5_INPUT_METER-VARCHAR2-IN>$pdu5_input_meter</ns1:P232_PDU5_INPUT_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P231_PDU5_INPUT_STATUS-VARCHAR2-IN>$pdu5_input_status</ns1:P231_PDU5_INPUT_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P230_PDU5_OUTLET_METER-VARCHAR2-IN>$pdu5_outlet_meter</ns1:P230_PDU5_OUTLET_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P229_PDU5_OUTLET_STATUS-VARCHAR2-IN>$pdu5_outlet_status</ns1:P229_PDU5_OUTLET_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P228_PDU5_CONN_TYPE-VARCHAR2-IN>$pdu5_conn_type</ns1:P228_PDU5_CONN_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P227_PDU5_FEATURES-VARCHAR2-IN>$pdu5_features</ns1:P227_PDU5_FEATURES-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P226_PDU5_FIRMWARE_VERSION-VARCHAR2-IN>$pdu5_firmware_version</ns1:P226_PDU5_FIRMWARE_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P225_PDU5_MODEL-VARCHAR2-IN>$pdu5_model</ns1:P225_PDU5_MODEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P224_PDU5_SN-VARCHAR2-IN>$pdu5_sn</ns1:P224_PDU5_SN-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P223_PDU4_ALLOWED_IP-VARCHAR2-IN>$pdu4_allowed_ip</ns1:P223_PDU4_ALLOWED_IP-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P222_PDU4_SNMP_COMM_RW-VARCHAR2-IN>$pdu4_snmp_comm_rw</ns1:P222_PDU4_SNMP_COMM_RW-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P221_PDU4_SNMP_COMM_RO-VARCHAR2-IN>$pdu4_snmp_comm_ro</ns1:P221_PDU4_SNMP_COMM_RO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P220_PDU4_SNMP_VERSION-VARCHAR2-IN>$pdu4_snmp_version</ns1:P220_PDU4_SNMP_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P219_PDU4_GATEWAY-VARCHAR2-IN>$pdu4_gateway</ns1:P219_PDU4_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P218_PDU4_NETMASK-VARCHAR2-IN>$pdu4_netmask</ns1:P218_PDU4_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P217_PDU4_IP_ADDRESS-VARCHAR2-IN>$pdu4_ip_address</ns1:P217_PDU4_IP_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P216_PDU4_INPUT_METER-VARCHAR2-IN>$pdu4_input_meter</ns1:P216_PDU4_INPUT_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P215_PDU4_INPUT_STATUS-VARCHAR2-IN>$pdu4_input_status</ns1:P215_PDU4_INPUT_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P214_PDU4_OUTLET_METER-VARCHAR2-IN>$pdu4_outlet_meter</ns1:P214_PDU4_OUTLET_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P213_PDU4_OUTLET_STATUS-VARCHAR2-IN>$pdu4_outlet_status</ns1:P213_PDU4_OUTLET_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P212_PDU4_CONN_TYPE-VARCHAR2-IN>$pdu4_conn_type</ns1:P212_PDU4_CONN_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P211_PDU4_FEATURES-VARCHAR2-IN>$pdu4_features</ns1:P211_PDU4_FEATURES-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P210_PDU4_FIRMWARE_VERSION-VARCHAR2-IN>$pdu4_firmware_version</ns1:P210_PDU4_FIRMWARE_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P209_PDU4_MODEL-VARCHAR2-IN>$pdu4_model</ns1:P209_PDU4_MODEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P208_PDU4_SN-VARCHAR2-IN>$pdu4_sn</ns1:P208_PDU4_SN-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P207_PDU3_ALLOWED_IP-VARCHAR2-IN>$pdu3_allowed_ip</ns1:P207_PDU3_ALLOWED_IP-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P206_PDU3_SNMP_COMM_RW-VARCHAR2-IN>$pdu3_snmp_comm_rw</ns1:P206_PDU3_SNMP_COMM_RW-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P205_PDU3_SNMP_COMM_RO-VARCHAR2-IN>$pdu3_snmp_comm_ro</ns1:P205_PDU3_SNMP_COMM_RO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P204_PDU3_SNMP_VERSION-VARCHAR2-IN>$pdu3_snmp_version</ns1:P204_PDU3_SNMP_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P203_PDU3_GATEWAY-VARCHAR2-IN>$pdu3_gateway</ns1:P203_PDU3_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P202_PDU3_NETMASK-VARCHAR2-IN>$pdu3_netmask</ns1:P202_PDU3_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P201_PDU3_IP_ADDRESS-VARCHAR2-IN>$pdu3_ip_address</ns1:P201_PDU3_IP_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P200_PDU3_INPUT_METER-VARCHAR2-IN>$pdu3_input_meter</ns1:P200_PDU3_INPUT_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P199_PDU3_INPUT_STATUS-VARCHAR2-IN>$pdu3_input_status</ns1:P199_PDU3_INPUT_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P198_PDU3_OUTLET_METER-VARCHAR2-IN>$pdu3_outlet_meter</ns1:P198_PDU3_OUTLET_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P197_PDU3_OUTLET_STATUS-VARCHAR2-IN>$pdu3_outlet_status</ns1:P197_PDU3_OUTLET_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P196_PDU3_CONN_TYPE-VARCHAR2-IN>$pdu3_conn_type</ns1:P196_PDU3_CONN_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P195_PDU3_FEATURES-VARCHAR2-IN>$pdu3_features</ns1:P195_PDU3_FEATURES-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P194_PDU3_FIRMWARE_VERSION-VARCHAR2-IN>$pdu3_firmware_version</ns1:P194_PDU3_FIRMWARE_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P193_PDU3_MODEL-VARCHAR2-IN>$pdu3_model</ns1:P193_PDU3_MODEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P192_PDU3_SN-VARCHAR2-IN>$pdu3_sn</ns1:P192_PDU3_SN-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P191_PDU2_ALLOWED_IP-VARCHAR2-IN>$pdu2_allowed_ip</ns1:P191_PDU2_ALLOWED_IP-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P190_PDU2_SNMP_COMM_RW-VARCHAR2-IN>$pdu2_snmp_comm_rw</ns1:P190_PDU2_SNMP_COMM_RW-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P189_PDU2_SNMP_COMM_RO-VARCHAR2-IN>$pdu2_snmp_comm_ro</ns1:P189_PDU2_SNMP_COMM_RO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P188_PDU2_SNMP_VERSION-VARCHAR2-IN>$pdu2_snmp_version</ns1:P188_PDU2_SNMP_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P187_PDU2_GATEWAY-VARCHAR2-IN>$pdu2_gateway</ns1:P187_PDU2_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P186_PDU2_NETMASK-VARCHAR2-IN>$pdu2_netmask</ns1:P186_PDU2_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P185_PDU2_IP_ADDRESS-VARCHAR2-IN>$pdu2_ip_address</ns1:P185_PDU2_IP_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P184_PDU2_INPUT_METER-VARCHAR2-IN>$pdu2_input_meter</ns1:P184_PDU2_INPUT_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P183_PDU2_INPUT_STATUS-VARCHAR2-IN>$pdu2_input_status</ns1:P183_PDU2_INPUT_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P182_PDU2_OUTLET_METER-VARCHAR2-IN>$pdu2_outlet_meter</ns1:P182_PDU2_OUTLET_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P181_PDU2_OUTLET_STATUS-VARCHAR2-IN>$pdu2_outlet_status</ns1:P181_PDU2_OUTLET_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P180_PDU2_CONN_TYPE-VARCHAR2-IN>$pdu2_conn_type</ns1:P180_PDU2_CONN_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P179_PDU2_FEATURES-VARCHAR2-IN>$pdu2_features</ns1:P179_PDU2_FEATURES-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P178_PDU2_FIRMWARE_VERSION-VARCHAR2-IN>$pdu2_firmware_version</ns1:P178_PDU2_FIRMWARE_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P177_PDU2_MODEL-VARCHAR2-IN>$pdu2_model</ns1:P177_PDU2_MODEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P176_PDU2_SN-VARCHAR2-IN>$pdu2_sn</ns1:P176_PDU2_SN-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P175_PDU1_ALLOWED_IP-VARCHAR2-IN>$pdu1_allowed_ip</ns1:P175_PDU1_ALLOWED_IP-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P174_PDU1_SNMP_COMM_RW-VARCHAR2-IN>$pdu1_snmp_comm_rw</ns1:P174_PDU1_SNMP_COMM_RW-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P173_PDU1_SNMP_COMM_RO-VARCHAR2-IN>$pdu1_snmp_comm_ro</ns1:P173_PDU1_SNMP_COMM_RO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P172_PDU1_SNMP_VERSION-VARCHAR2-IN>$pdu1_snmp_version</ns1:P172_PDU1_SNMP_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P171_PDU1_GATEWAY-VARCHAR2-IN>$pdu1_gateway</ns1:P171_PDU1_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P170_PDU1_NETMASK-VARCHAR2-IN>$pdu1_netmask</ns1:P170_PDU1_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P169_PDU1_IP_ADDRESS-VARCHAR2-IN>$pdu1_ip_address</ns1:P169_PDU1_IP_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P168_PDU1_INPUT_METER-VARCHAR2-IN>$pdu1_input_meter</ns1:P168_PDU1_INPUT_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P167_PDU1_INPUT_STATUS-VARCHAR2-IN>$pdu1_input_status</ns1:P167_PDU1_INPUT_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P166_PDU1_OUTLET_METER-VARCHAR2-IN>$pdu1_outlet_meter</ns1:P166_PDU1_OUTLET_METER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P165_PDU1_OUTLET_STATUS-VARCHAR2-IN>$pdu1_outlet_status</ns1:P165_PDU1_OUTLET_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P164_PDU1_CONN_TYPE-VARCHAR2-IN>$pdu1_conn_type</ns1:P164_PDU1_CONN_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P163_PDU1_FEATURES-VARCHAR2-IN>$pdu1_features</ns1:P163_PDU1_FEATURES-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P162_PDU1_FIRMWARE_VERSION-VARCHAR2-IN>$pdu1_firmware_version</ns1:P162_PDU1_FIRMWARE_VERSION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P161_PDU1_MODEL-VARCHAR2-IN>$pdu1_model</ns1:P161_PDU1_MODEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P160_PDU1_SN-VARCHAR2-IN>$pdu1_sn</ns1:P160_PDU1_SN-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P159_COM24_PHY-VARCHAR2-IN>$humidity</ns1:P159_COM24_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P158_COM24_NAME-VARCHAR2-IN>$temperature</ns1:P158_COM24_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P157_COM23_PHY-VARCHAR2-IN>$com23_phy</ns1:P157_COM23_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P156_COM23_NAME-VARCHAR2-IN>$io4</ns1:P156_COM23_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P155_COM22_PHY-VARCHAR2-IN>$com22_phy</ns1:P155_COM22_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P154_COM22_NAME-VARCHAR2-IN>$io3</ns1:P154_COM22_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P153_COM21_PHY-VARCHAR2-IN>$com21_phy</ns1:P153_COM21_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P152_COM21_NAME-VARCHAR2-IN>$io2</ns1:P152_COM21_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P151_COM20_PHY-VARCHAR2-IN>$com20_phy</ns1:P151_COM20_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P150_COM20_NAME-VARCHAR2-IN>$io1</ns1:P150_COM20_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P149_COM19_PHY-VARCHAR2-IN>$com19_phy</ns1:P149_COM19_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P148_COM19_NAME-VARCHAR2-IN>$com19_name</ns1:P148_COM19_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P147_COM18_PHY-VARCHAR2-IN>$com18_phy</ns1:P147_COM18_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P146_COM18_NAME-VARCHAR2-IN>$com18_name</ns1:P146_COM18_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P145_COM17_PHY-VARCHAR2-IN>$com17_phy</ns1:P145_COM17_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P144_COM17_NAME-VARCHAR2-IN>$com17_name</ns1:P144_COM17_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P143_COM16_PHY-VARCHAR2-IN>$com16_phy</ns1:P143_COM16_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P142_COM16_NAME-VARCHAR2-IN>$com16_name</ns1:P142_COM16_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P141_COM15_PHY-VARCHAR2-IN>$com15_phy</ns1:P141_COM15_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P140_COM15_NAME-VARCHAR2-IN>$com15_name</ns1:P140_COM15_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P139_COM14_PHY-VARCHAR2-IN>$com14_phy</ns1:P139_COM14_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P138_COM14_NAME-VARCHAR2-IN>$com14_name</ns1:P138_COM14_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P137_COM13_PHY-VARCHAR2-IN>$com13_phy</ns1:P137_COM13_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P136_COM13_NAME-VARCHAR2-IN>$com13_name</ns1:P136_COM13_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P135_COM12_PHY-VARCHAR2-IN>$com12_phy</ns1:P135_COM12_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P134_COM12_NAME-VARCHAR2-IN>$com12_name</ns1:P134_COM12_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P133_COM11_PHY-VARCHAR2-IN>$com11_phy</ns1:P133_COM11_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P132_COM11_NAME-VARCHAR2-IN>$com11_name</ns1:P132_COM11_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P131_COM10_PHY-VARCHAR2-IN>$com10_phy</ns1:P131_COM10_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P130_COM10_NAME-VARCHAR2-IN>$com10_name</ns1:P130_COM10_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P129_COM9_PHY-VARCHAR2-IN>$com9_phy</ns1:P129_COM9_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P128_COM9_NAME-VARCHAR2-IN>$com9_name</ns1:P128_COM9_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P127_COM8_PHY-VARCHAR2-IN>$com8_phy</ns1:P127_COM8_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P126_COM8_NAME-VARCHAR2-IN>$com8_name</ns1:P126_COM8_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P125_COM7_PHY-VARCHAR2-IN>$com7_phy</ns1:P125_COM7_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P124_COM7_NAME-VARCHAR2-IN>$com7_name</ns1:P124_COM7_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P123_COM6_PHY-VARCHAR2-IN>$com6_phy</ns1:P123_COM6_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P122_COM6_NAME-VARCHAR2-IN>$com6_name</ns1:P122_COM6_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P121_COM5_PHY-VARCHAR2-IN>$com5_phy</ns1:P121_COM5_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P120_COM5_NAME-VARCHAR2-IN>$com5_name</ns1:P120_COM5_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P119_COM4_PHY-VARCHAR2-IN>$com4_phy</ns1:P119_COM4_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P118_COM4_NAME-VARCHAR2-IN>$com4_name</ns1:P118_COM4_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P117_COM3_PHY-VARCHAR2-IN>$com3_phy</ns1:P117_COM3_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P116_COM3_NAME-VARCHAR2-IN>$com3_name</ns1:P116_COM3_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P115_COM2_PHY-VARCHAR2-IN>$com2_phy</ns1:P115_COM2_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P114_COM2_NAME-VARCHAR2-IN>$com2_name</ns1:P114_COM2_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P113_COM1_PHY-VARCHAR2-IN>$com1_phy</ns1:P113_COM1_PHY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P112_COM1_NAME-VARCHAR2-IN>$com1_name</ns1:P112_COM1_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P111_WEB_CAM_STATUS-VARCHAR2-IN>$web_cam_status</ns1:P111_WEB_CAM_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P110_WEB_CAM_TYPE-VARCHAR2-IN>$web_cam_type</ns1:P110_WEB_CAM_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P109_MODEM_STATUS-VARCHAR2-IN>$modem_status</ns1:P109_MODEM_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P108_MODEM_TYPE-VARCHAR2-IN>$modem_type</ns1:P108_MODEM_TYPE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P107_NTP4-VARCHAR2-IN>$ntp4</ns1:P107_NTP4-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P106_NTP3-VARCHAR2-IN>$ntp3</ns1:P106_NTP3-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P105_NTP2-VARCHAR2-IN>$ntp2</ns1:P105_NTP2-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P104_NTP1-VARCHAR2-IN>$ntp1</ns1:P104_NTP1-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P103_DNS4-VARCHAR2-IN>$dns4</ns1:P103_DNS4-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P102_DNS3-VARCHAR2-IN>$dns3</ns1:P102_DNS3-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P101_DNS2-VARCHAR2-IN>$dns2</ns1:P101_DNS2-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P100_DNS1-VARCHAR2-IN>$dns1</ns1:P100_DNS1-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P099_NETMON_TIMEOUT-VARCHAR2-IN>$netmon_timeout</ns1:P099_NETMON_TIMEOUT-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P098_NETMON_HOSTS-VARCHAR2-IN>$netmon_hosts</ns1:P098_NETMON_HOSTS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P097_NETMON_INTERVAL-VARCHAR2-IN>$netmon_interval</ns1:P097_NETMON_INTERVAL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P096_NETFW_INTERFACE_PRI-VARCHAR2-IN>$netfw_interface_pri</ns1:P096_NETFW_INTERFACE_PRI-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P095_NETMON_PACKETS-VARCHAR2-IN>$netmon_packets</ns1:P095_NETMON_PACKETS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P094_NETFW_HOSTS-VARCHAR2-IN>$netfw_hosts</ns1:P094_NETFW_HOSTS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P093_INT6_DHCP_DNS-VARCHAR2-IN>$int6_dhcp_dns</ns1:P093_INT6_DHCP_DNS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P092_INT6_DHCP_GATEWAY-VARCHAR2-IN>$int6_dhcp_gateway</ns1:P092_INT6_DHCP_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P091_INT6_DHCP_NETMASK-VARCHAR2-IN>$int6_dhcp_netmask</ns1:P091_INT6_DHCP_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P090_INT6_DHCP_NETWORK-VARCHAR2-IN>$int6_dhcp_network</ns1:P090_INT6_DHCP_NETWORK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P089_INT6_DHCP_SERVER-VARCHAR2-IN>$int6_dhcp_server</ns1:P089_INT6_DHCP_SERVER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P088_INT6_KEY-VARCHAR2-IN>$int6_key</ns1:P088_INT6_KEY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P087_INT6_SSID-VARCHAR2-IN>$int6_ssid</ns1:P087_INT6_SSID-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P086_INT6_SIGNAL_LEVEL-VARCHAR2-IN>$int6_signal_level</ns1:P086_INT6_SIGNAL_LEVEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P085_INT6_MODE-VARCHAR2-IN>$int6_mode</ns1:P085_INT6_MODE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P084_INT6_ENCRYPTION-VARCHAR2-IN>$int6_encryption</ns1:P084_INT6_ENCRYPTION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P083_INT6_GATEWAY-VARCHAR2-IN>$int6_gateway</ns1:P083_INT6_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P082_INT6_NETMASK-VARCHAR2-IN>$int6_netmask</ns1:P082_INT6_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P081_INT6_ADDRESS-VARCHAR2-IN>$int6_address</ns1:P081_INT6_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P080_INT6_PROTO-VARCHAR2-IN>$int6_proto</ns1:P080_INT6_PROTO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P079_INT6_AVG_DELAY-VARCHAR2-IN>$int6_avg_delay</ns1:P079_INT6_AVG_DELAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P078_INT6_PACKET_LOSS-VARCHAR2-IN>$int6_packet_loss</ns1:P078_INT6_PACKET_LOSS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P077_INT6_CURR_STATE-VARCHAR2-IN>$int6_curr_state</ns1:P077_INT6_CURR_STATE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P076_INT6_ADMIN_STATUS-VARCHAR2-IN>$int6_admin_status</ns1:P076_INT6_ADMIN_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P075_INT6_NAME-VARCHAR2-IN>$int6_name</ns1:P075_INT6_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P074_INT5_GATEWAY-VARCHAR2-IN>$int5_gateway</ns1:P074_INT5_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P073_INT5_NETMASK-VARCHAR2-IN>$int5_netmask</ns1:P073_INT5_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P072_INT5_ADDRESS-VARCHAR2-IN>$int5_address</ns1:P072_INT5_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P071_INT5_BALANCE-VARCHAR2-IN>$int5_balance</ns1:P071_INT5_BALANCE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P070_INT5_SIGNAL_LEVEL-VARCHAR2-IN>$int5_signal_level</ns1:P070_INT5_SIGNAL_LEVEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P069_INT5_OPERATOR-VARCHAR2-IN>$int5_operator</ns1:P069_INT5_OPERATOR-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P068_INT5_PROTO-VARCHAR2-IN>$int5_proto</ns1:P068_INT5_PROTO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P067_INT5_AVG_DELAY-VARCHAR2-IN>$int5_avg_delay</ns1:P067_INT5_AVG_DELAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P066_INT5_PACKET_LOSS-VARCHAR2-IN>$int5_packet_loss</ns1:P066_INT5_PACKET_LOSS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P065_INT5_CURR_STATE-VARCHAR2-IN>$int5_curr_state</ns1:P065_INT5_CURR_STATE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P064_INT5_ADMIN_STATUS-VARCHAR2-IN>$int5_admin_status</ns1:P064_INT5_ADMIN_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P063_INT5_NAME-VARCHAR2-IN>$int5_name</ns1:P063_INT5_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P062_INT4_GATEWAY-VARCHAR2-IN>$int4_gateway</ns1:P062_INT4_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P061_INT4_NETMASK-VARCHAR2-IN>$int4_netmask</ns1:P061_INT4_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P060_INT4_ADDRESS-VARCHAR2-IN>$int4_address</ns1:P060_INT4_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P059_INT4_PROTO-VARCHAR2-IN>$int4_proto</ns1:P059_INT4_PROTO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P058_INT4_AVG_DELAY-VARCHAR2-IN>$int4_avg_delay</ns1:P058_INT4_AVG_DELAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P057_INT4_PACKET_LOSS-VARCHAR2-IN>$int4_packet_loss</ns1:P057_INT4_PACKET_LOSS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P056_INT4_CURR_STATE-VARCHAR2-IN>$int4_curr_state</ns1:P056_INT4_CURR_STATE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P055_INT4_ADMIN_STATUS-VARCHAR2-IN>$int4_admin_status</ns1:P055_INT4_ADMIN_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P054_INT4_NAME-VARCHAR2-IN>$int4_name</ns1:P054_INT4_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P053_INT3_DHCP_DNS-VARCHAR2-IN>$int3_dhcp_dns</ns1:P053_INT3_DHCP_DNS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P052_INT3_DHCP_GATEWAY-VARCHAR2-IN>$int3_dhcp_gateway</ns1:P052_INT3_DHCP_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P051_INT3_DHCP_NETMASK-VARCHAR2-IN>$int3_dhcp_netmask</ns1:P051_INT3_DHCP_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P050_INT3_DHCP_NETWORK-VARCHAR2-IN>$int3_dhcp_network</ns1:P050_INT3_DHCP_NETWORK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P049_INT3_DHCP_SERVER-VARCHAR2-IN>$int3_dhcp_server</ns1:P049_INT3_DHCP_SERVER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P048_INT3_KEY-VARCHAR2-IN>$int3_key</ns1:P048_INT3_KEY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P047_INT3_SSID-VARCHAR2-IN>$int3_ssid</ns1:P047_INT3_SSID-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P046_INT3_SIGNAL_LEVEL-VARCHAR2-IN>$int3_signal_level</ns1:P046_INT3_SIGNAL_LEVEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P045_INT3_MODE-VARCHAR2-IN>$int3_mode</ns1:P045_INT3_MODE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P044_INT3_ENCRYPTION-VARCHAR2-IN>$int3_encryption</ns1:P044_INT3_ENCRYPTION-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P043_INT3_GATEWAY-VARCHAR2-IN>$int3_gateway</ns1:P043_INT3_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P042_INT3_NETMASK-VARCHAR2-IN>$int3_netmask</ns1:P042_INT3_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P041_INT3_ADDRESS-VARCHAR2-IN>$int3_address</ns1:P041_INT3_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P040_INT3_PROTO-VARCHAR2-IN>$int3_proto</ns1:P040_INT3_PROTO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P039_INT3_AVG_DELAY-VARCHAR2-IN>$int3_avg_delay</ns1:P039_INT3_AVG_DELAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P038_INT3_PACKET_LOSS-VARCHAR2-IN>$int3_packet_loss</ns1:P038_INT3_PACKET_LOSS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P037_INT3_CURR_STATE-VARCHAR2-IN>$int3_curr_state</ns1:P037_INT3_CURR_STATE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P036_INT3_ADMIN_STATUS-VARCHAR2-IN>$int3_admin_status</ns1:P036_INT3_ADMIN_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P035_INT3_NAME-VARCHAR2-IN>$int3_name</ns1:P035_INT3_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P034_INT2_GATEWAY-VARCHAR2-IN>$int2_gateway</ns1:P034_INT2_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P033_INT2_NETMASK-VARCHAR2-IN>$int2_netmask</ns1:P033_INT2_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P032_INT2_ADDRESS-VARCHAR2-IN>$int2_address</ns1:P032_INT2_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P031_INT2_BALANCE-VARCHAR2-IN>$int2_balance</ns1:P031_INT2_BALANCE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P030_INT2_SIGNAL_LEVEL-VARCHAR2-IN>$int2_signal_level</ns1:P030_INT2_SIGNAL_LEVEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P029_INT2_OPERATOR-VARCHAR2-IN>$int2_operator</ns1:P029_INT2_OPERATOR-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P028_INT2_PROTO-VARCHAR2-IN>$int2_proto</ns1:P028_INT2_PROTO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P027_INT2_AVG_DELAY-VARCHAR2-IN>$int2_avg_delay</ns1:P027_INT2_AVG_DELAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P026_INT2_PACKET_LOSS-VARCHAR2-IN>$int2_packet_loss</ns1:P026_INT2_PACKET_LOSS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P025_INT2_CURR_STATE-VARCHAR2-IN>$int2_curr_state</ns1:P025_INT2_CURR_STATE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P024_INT2_ADMIN_STATUS-VARCHAR2-IN>$int2_admin_status</ns1:P024_INT2_ADMIN_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P023_INT2_NAME-VARCHAR2-IN>$int2_name</ns1:P023_INT2_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P022_INT1_GATEWAY-VARCHAR2-IN>$int1_gateway</ns1:P022_INT1_GATEWAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P021_INT1_NETMASK-VARCHAR2-IN>$int1_netmask</ns1:P021_INT1_NETMASK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P020_INT1_ADDRESS-VARCHAR2-IN>$int1_address</ns1:P020_INT1_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P019_INT1_PROTO-VARCHAR2-IN>$int1_proto</ns1:P019_INT1_PROTO-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P018_INT1_AVG_DELAY-VARCHAR2-IN>$int1_avg_delay</ns1:P018_INT1_AVG_DELAY-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P017_INT1_PACKET_LOSS-VARCHAR2-IN>$int1_packet_loss</ns1:P017_INT1_PACKET_LOSS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P016_INT1_CURR_STATE-VARCHAR2-IN>$int1_curr_state</ns1:P016_INT1_CURR_STATE-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P015_INT1_ADMIN_STATUS-VARCHAR2-IN>$int1_admin_status</ns1:P015_INT1_ADMIN_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P014_INT1_NAME-VARCHAR2-IN>$int1_name</ns1:P014_INT1_NAME-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P013_APP_PORT_COUNT-VARCHAR2-IN>$app_port_count</ns1:P013_APP_PORT_COUNT-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P012_APP_ACTIVE_IF-VARCHAR2-IN>$app_active_if</ns1:P012_APP_ACTIVE_IF-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P011_APP_VPN_ADDRESS-VARCHAR2-IN>$app_vpn_address</ns1:P011_APP_VPN_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P010_APP_VPN_STATUS-VARCHAR2-IN>$app_vpn_status</ns1:P010_APP_VPN_STATUS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P009_REPO_ADDRESS-VARCHAR2-IN>$control_url</ns1:P009_REPO_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P008_MGR_VPN_PORT-VARCHAR2-IN>$mgr_vpn_port</ns1:P008_MGR_VPN_PORT-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P007_MGR_VPN_ADDRESS-VARCHAR2-IN>$mgr_vpn_address</ns1:P007_MGR_VPN_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P006_MGR_ADDRESS-VARCHAR2-IN>$mgr_address</ns1:P006_MGR_ADDRESS-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P005_CONFIG_VER-VARCHAR2-IN>$config_ver</ns1:P005_CONFIG_VER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P004_SYS_LOCK-VARCHAR2-IN>$sys_lock</ns1:P004_SYS_LOCK-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P003_SYS_VER-VARCHAR2-IN>$sys_ver</ns1:P003_SYS_VER-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P002_SYS_MODEL-VARCHAR2-IN>$sys_model</ns1:P002_SYS_MODEL-VARCHAR2-IN>" >> /tmp/register.xml
		echo "      <ns1:P001_SYS_SN-VARCHAR2-IN>$sys_sn</ns1:P001_SYS_SN-VARCHAR2-IN>" >> /tmp/register.xml
		echo "    </ns1:REGISTERInput>" >> /tmp/register.xml
		echo "  </s11:Body>" >> /tmp/register.xml
		echo "</s11:Envelope>" >> /tmp/register.xml

		soap_user=`cat /usr/local/cms/config/soap | grep "soap_user" | awk -F "=" '{print $2}'`
		soap_password=`cat /usr/local/cms/config/soap | grep "soap_password" | awk -F "=" '{print $2}'`
		soap_host=`cat /usr/local/cms/config/soap | grep "soap_host" | awk -F "=" '{print $2}'`
		soap_port=`cat /usr/local/cms/config/soap | grep "soap_port" | awk -F "=" '{print $2}'`
		soap_resource=`cat /usr/local/cms/config/soap | grep "soap_resource" | awk -F "=" '{print $2}'`


		echo "curl -X POST -d @/tmp/register.xml --connect-timeout 120 -H \"Content-Type: text/xml;charset=UTF-8\" \
		http://$soap_user:$soap_password@$soap_host:$soap_port$soap_resource" | /bin/bash

		fi
