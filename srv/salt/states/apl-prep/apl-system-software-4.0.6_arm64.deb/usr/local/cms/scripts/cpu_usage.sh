#!/bin/bash
# by Paul Colby (http://colby.id.au), no rights reserved ;)
# 	modified by Konstantin Gusenko <kenga13@gmail.com> , no rights reserved

db=/tmp/cpu_usage.dat

CPU=(`cat /proc/stat | grep '^cpu '`) # Get the total CPU statistics.
  unset CPU[0]                          # Discard the "cpu" prefix.

# Get previous
if [ -s $db ]; then
	PREV=(`cat ${db}`)
	PREV_TOTAL=${PREV[0]}
	PREV_IDLE=${PREV[1]}
else
	PREV_TOTAL=0
	PREV_IDLE=0
fi

  IDLE=${CPU[4]}                        # Get the idle CPU time.
# Calculate the total CPU time.
  TOTAL=0
for VALUE in "${CPU[@]:0:4}"; do
    let "TOTAL=$TOTAL+$VALUE"
done
# Calculate the CPU usage since we last checked.
let "DIFF_IDLE=$IDLE-$PREV_IDLE"
let "DIFF_TOTAL=$TOTAL-$PREV_TOTAL"
let "DIFF_USAGE=(1000*($DIFF_TOTAL-$DIFF_IDLE)/$DIFF_TOTAL+5)/10"
echo -e "$DIFF_USAGE"
echo "$TOTAL $IDLE" > $db


