#!/bin/bash

while true
do

soap_host=`cat /usr/local/cms/config/soap | grep "soap_host" | awk -F "=" '{print $2}'`
ping -q -c2 $soap_host > /dev/null

if [ $? -eq 0 ]
then
	vpn_status="1"
else
	vpn_status="0"
fi

if [ "$vpn_status" == "1" ]
then
	echo heartbeat > /sys/class/leds/blue\:heartbeat/trigger
	#sudo /usr/local/cms/bin/ledcontrol set led vpn on
	#sudo /usr/local/cms/bin/ledcontrol set led power on
else
	sudo echo none > /sys/class/leds/blue\:heartbeat/trigger
	#sudo /usr/local/cms/bin/ledcontrol set led vpn off
	#sudo /usr/local/cms/bin/ledcontrol set led power on
fi

sleep 10
done
