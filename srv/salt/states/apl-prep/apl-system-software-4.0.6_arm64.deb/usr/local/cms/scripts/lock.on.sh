#! /bin/bash

cat /usr/local/cms/scripts/menu.lock.on.sh > /usr/local/cms/scripts/menu.sh
iptables -I INPUT 4 -p tcp --dport 22 -j DROP
iptables -I INPUT -i eth0 -p icmp --icmp-type echo-request -j DROP
iptables -I INPUT -i wlan0 -p icmp --icmp-type echo-request -j DROP
iptables -I INPUT -i usb0 -p icmp --icmp-type echo-request -j DROP

