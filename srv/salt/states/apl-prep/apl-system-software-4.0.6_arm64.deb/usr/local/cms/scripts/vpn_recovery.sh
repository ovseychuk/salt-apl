#!/bin/bash

source /usr/local/cms/config/soap

while true
do
  if ! ping -q -c2 ${soap_host} &> /dev/null;
  then
    systemctl restart openvpn@client
  fi
  sleep 60
done
